#!/bin/bash
# ============================================================
# Aerora Dynamics — Cloud Backend
# cloud/scripts/deploy.sh — One-command cloud deployment
#
# Usage:
#   ./cloud/scripts/deploy.sh           # deploy/update
#   ./cloud/scripts/deploy.sh --logs    # tail logs after deploy
#   ./cloud/scripts/deploy.sh --down    # stop everything
# ============================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
COMPOSE_FILE="$REPO_ROOT/cloud/docker/docker-compose.prod.yml"

cd "$REPO_ROOT"

echo -e "${CYAN}"
echo "  ============================================"
echo "   AERORA DYNAMICS — CLOUD DEPLOYMENT"
echo "  ============================================"
echo -e "${NC}"

if [ "$1" = "--down" ]; then
  echo -e "${YELLOW}Stopping all cloud services...${NC}"
  docker-compose -f "$COMPOSE_FILE" down
  echo -e "${GREEN}Done.${NC}"
  exit 0
fi

# ── Pre-flight checks ──────────────────────────────────────────
if [ ! -f "$REPO_ROOT/.env.production" ]; then
  echo -e "${RED}Missing .env.production${NC}"
  echo "  Copy the template: cp cloud/.env.production.example .env.production"
  echo "  Then fill in your values before deploying."
  exit 1
fi

if ! command -v docker &> /dev/null; then
  echo -e "${RED}Docker not found. Install: https://docs.docker.com/get-docker/${NC}"
  exit 1
fi

if ! command -v docker-compose &> /dev/null; then
  echo -e "${RED}docker-compose not found. Install: https://docs.docker.com/compose/install/${NC}"
  exit 1
fi

# ── Build and deploy ───────────────────────────────────────────
echo -e "${CYAN}Building images (this may take 3-5 minutes)...${NC}"
docker-compose -f "$COMPOSE_FILE" build

echo -e "${CYAN}Starting services...${NC}"
docker-compose -f "$COMPOSE_FILE" up -d

echo -e "${CYAN}Waiting for API health check...${NC}"
for i in $(seq 1 30); do
  if curl -sf http://localhost:8080/api/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ API is healthy!${NC}"
    break
  fi
  sleep 2
  if [ "$i" = "30" ]; then
    echo -e "${RED}API did not become healthy in time. Check logs:${NC}"
    echo "  docker-compose -f $COMPOSE_FILE logs aerora-api"
  fi
done

echo ""
echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}  Deployment complete!${NC}"
echo -e "${GREEN}============================================${NC}"
echo ""
echo "  API:     http://localhost:8080/docs"
echo "  Health:  http://localhost:8080/api/health"
echo ""
echo "  View logs:    docker-compose -f $COMPOSE_FILE logs -f"
echo "  Stop:         ./cloud/scripts/deploy.sh --down"
echo ""

if [ "$1" = "--logs" ]; then
  docker-compose -f "$COMPOSE_FILE" logs -f
fi
