"""
Aerora Dynamics — Cloud API
routers/social_router.py — Social media posts & broadcast

Wraps aerora_dynamics/social_manager.py + database.py SocialDB
"""

import os, sys
from typing import Optional, List
from fastapi import APIRouter, Depends
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master"), os.path.join(REPO, "aerora_dynamics")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


class PostCreate(BaseModel):
    platform:     str
    content:      str
    hashtags:     Optional[List[str]] = []
    scheduled_at: Optional[str] = None

class BroadcastRequest(BaseModel):
    content:   str
    platforms: List[str]


@router.get("/posts")
async def get_posts(platform: Optional[str] = None, status: Optional[str] = None,
                    user=Depends(get_current_user)):
    from database import SocialDB
    if status:
        return SocialDB.get_queue(platform=platform, status=status)
    return SocialDB.get_all_posts()


@router.post("/posts", status_code=201)
async def create_post(body: PostCreate, user=Depends(get_current_user)):
    from database import SocialDB
    pid = SocialDB.queue_post(body.platform, body.content,
                               hashtags=body.hashtags, scheduled_at=body.scheduled_at)
    return {"post_id": pid, "success": True}


@router.post("/broadcast")
async def broadcast(body: BroadcastRequest, user=Depends(get_current_user)):
    from social_manager import SocialManager
    sm = SocialManager()
    results = sm.broadcast(body.content, platforms=body.platforms)
    return {
        platform: {"success": r.success, "post_id": r.post_id, "error": r.error}
        for platform, r in results.items()
    }


@router.get("/connections")
async def test_connections(user=Depends(get_current_user)):
    """Check which social platforms have valid credentials configured."""
    from config import cfg
    return {
        "twitter":   cfg.has_twitter,
        "linkedin":  cfg.has_linkedin,
        "instagram": cfg.has_instagram,
    }


@router.get("/analytics")
async def social_analytics(user=Depends(get_current_user)):
    from database import SocialDB
    return SocialDB.posts_summary()
