"""
Aerora Dynamics — Cloud API
routers/build_router.py — Build & Operations

Wraps aerora_master/master_database.py: BuildDB, BomDB, IssueDB, MilestoneDB
"""

import os, sys
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


# ── Models ────────────────────────────────────────────────────
class UnitCreate(BaseModel):
    unit_id:    str
    model_name: str
    location:   Optional[str] = ""
    notes:      Optional[str] = ""

class StatusUpdate(BaseModel):
    status: str

class LogCreate(BaseModel):
    unit_id:     str
    log_type:    str
    title:       str
    description: Optional[str] = ""
    hours_spent: Optional[float] = 0

class TestCreate(BaseModel):
    unit_id:           str
    test_type:         str
    date_flown:        str
    duration_mins:      float
    result:             str
    location:           Optional[str] = ""
    anomalies:          Optional[str] = ""
    corrective_action:  Optional[str] = ""
    weather:            Optional[str] = ""
    max_altitude_m:      Optional[float] = 0
    max_speed_kph:       Optional[float] = 0

class PartCreate(BaseModel):
    part_number:    str
    name:           str
    category:       str
    unit_cost_gbp:  float
    quantity_stock: int
    quantity_min:   int
    supplier:       Optional[str] = ""
    lead_time_days: Optional[int] = 0

class StockUpdate(BaseModel):
    quantity: int

class OrderCreate(BaseModel):
    part_number:   str
    quantity:      int
    unit_cost:     Optional[float] = 0
    supplier:      Optional[str] = ""
    expected_date: Optional[str] = ""

class IssueCreate(BaseModel):
    title:        str
    unit_id:      Optional[str] = ""
    description:  Optional[str] = ""
    severity:     Optional[str] = "medium"
    category:     Optional[str] = "Hardware"
    assigned_to:  Optional[int] = None

class IssueUpdate(BaseModel):
    status:     Optional[str] = None
    resolution: Optional[str] = None

class MilestoneCreate(BaseModel):
    title:       str
    category:    str
    target_date: str
    description: Optional[str] = ""

class MilestoneUpdate(BaseModel):
    status: str


# ── Drone Units ───────────────────────────────────────────────
@router.get("/units")
async def get_units(user=Depends(get_current_user)):
    from master_database import BuildDB
    return BuildDB.get_all_units()


@router.post("/units", status_code=201)
async def create_unit(body: UnitCreate, user=Depends(get_current_user)):
    from master_database import BuildDB
    uid = BuildDB.create_unit(body.unit_id, body.model_name, user.id,
                               body.location, body.notes)
    return {"id": uid, "success": True}


@router.patch("/units/{unit_id}")
async def update_unit(unit_id: str, body: StatusUpdate, user=Depends(get_current_user)):
    from master_database import BuildDB
    BuildDB.update_unit_status(unit_id, body.status)
    return {"success": True}


# ── Build Logs ────────────────────────────────────────────────
@router.get("/logs")
async def get_logs(unit_id: Optional[str] = None, user=Depends(get_current_user)):
    from master_database import BuildDB
    return BuildDB.get_logs(unit_id) if unit_id else []


@router.post("/logs", status_code=201)
async def add_log(body: LogCreate, user=Depends(get_current_user)):
    from master_database import BuildDB
    lid = BuildDB.add_log(body.unit_id, user.id, body.log_type,
                          body.title, body.description, body.hours_spent)
    return {"id": lid, "success": True}


# ── Test Flights ──────────────────────────────────────────────
@router.get("/tests")
async def get_tests(unit_id: Optional[str] = None, user=Depends(get_current_user)):
    from master_database import BuildDB
    return BuildDB.get_tests(unit_id)


@router.post("/tests", status_code=201)
async def add_test(body: TestCreate, user=Depends(get_current_user)):
    from master_database import BuildDB
    tid = BuildDB.add_test(
        body.unit_id, user.id, body.test_type, body.date_flown,
        body.duration_mins, body.result, body.location,
        body.anomalies, body.corrective_action, body.weather,
        body.max_altitude_m, body.max_speed_kph,
    )
    return {"id": tid, "success": True}


# ── BOM ───────────────────────────────────────────────────────
@router.get("/bom")
async def get_bom(user=Depends(get_current_user)):
    from master_database import BomDB
    return BomDB.get_all()


@router.post("/bom", status_code=201)
async def add_part(body: PartCreate, user=Depends(get_current_user)):
    from master_database import BomDB
    pid = BomDB.add_part(**body.dict())
    return {"id": pid, "success": True}


@router.patch("/bom/{part_number}")
async def update_stock(part_number: str, body: StockUpdate, user=Depends(get_current_user)):
    from master_database import BomDB
    BomDB.update_stock(part_number, body.quantity)
    return {"success": True}


@router.get("/bom/low-stock")
async def low_stock(user=Depends(get_current_user)):
    from master_database import BomDB
    return BomDB.get_low_stock()


@router.get("/bom/orders")
async def get_orders(user=Depends(get_current_user)):
    from master_database import BomDB
    return BomDB.get_orders()


@router.post("/bom/orders", status_code=201)
async def place_order(body: OrderCreate, user=Depends(get_current_user)):
    from master_database import BomDB
    oid = BomDB.place_order(body.part_number, body.quantity, user.id,
                            body.supplier, body.unit_cost, body.expected_date)
    return {"id": oid, "success": True}


# ── Issues ────────────────────────────────────────────────────
@router.get("/issues")
async def get_issues(status: Optional[str] = None, user=Depends(get_current_user)):
    from master_database import IssueDB
    return IssueDB.get_all(status=status)


@router.post("/issues", status_code=201)
async def create_issue(body: IssueCreate, user=Depends(get_current_user)):
    from master_database import IssueDB
    iid = IssueDB.create(body.title, user.id, body.unit_id,
                         body.description, body.severity, body.category,
                         body.assigned_to)
    return {"id": iid, "success": True}


@router.patch("/issues/{issue_id}")
async def update_issue(issue_id: int, body: IssueUpdate, user=Depends(get_current_user)):
    from master_database import IssueDB
    if body.status:
        IssueDB.update_status(issue_id, body.status, body.resolution or "")
    return {"success": True}


# ── Milestones ────────────────────────────────────────────────
@router.get("/milestones")
async def get_milestones(user=Depends(get_current_user)):
    from master_database import MilestoneDB
    return MilestoneDB.get_all()


@router.post("/milestones", status_code=201)
async def create_milestone(body: MilestoneCreate, user=Depends(get_current_user)):
    from master_database import MilestoneDB
    mid = MilestoneDB.create(body.title, body.category, body.target_date,
                              user.id, body.description)
    return {"id": mid, "success": True}


@router.patch("/milestones/{milestone_id}")
async def update_milestone(milestone_id: int, body: MilestoneUpdate,
                           user=Depends(get_current_user)):
    from master_database import MilestoneDB
    MilestoneDB.update_status(milestone_id, body.status)
    return {"success": True}
