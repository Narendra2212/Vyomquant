"""
Aerora Dynamics — Cloud API
routers/finance_router.py — Finance & Budget

Wraps aerora_master/master_database.py: FinanceDB
"""

import os, sys
from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


class RunwaySnapshot(BaseModel):
    cash_balance_gbp: float
    monthly_burn_gbp: float
    notes: Optional[str] = ""
    next_fundraise_target_gbp: Optional[float] = 0

class BudgetItem(BaseModel):
    category:    str
    description: str
    amount_gbp:  float
    period:      str
    budget_type: Optional[str] = "opex"

class ExpenseSubmit(BaseModel):
    category:      str
    description:   str
    amount_gbp:    float
    expense_date:  str
    receipt_path:  Optional[str] = ""

class GrantCreate(BaseModel):
    title:      str
    funder:     str
    grant_type: str
    amount_gbp: float
    deadline:   str

class GrantUpdate(BaseModel):
    status: Optional[str] = None
    notes:  Optional[str] = None


@router.get("/runway")
async def get_runway(user=Depends(get_current_user)):
    from master_database import FinanceDB
    return FinanceDB.get_latest_runway() or {}


@router.get("/runway/history")
async def runway_history(user=Depends(get_current_user)):
    from master_database import FinanceDB
    return FinanceDB.get_runway_history()


@router.post("/runway", status_code=201)
async def add_runway(body: RunwaySnapshot, user=Depends(get_current_user)):
    from master_database import FinanceDB
    rid = FinanceDB.add_runway_snapshot(
        body.cash_balance_gbp, body.monthly_burn_gbp, body.notes,
        user.id, body.next_fundraise_target_gbp
    )
    return {"id": rid, "success": True}


@router.get("/budget")
async def get_budget(period: Optional[str] = None, user=Depends(get_current_user)):
    from master_database import FinanceDB
    return FinanceDB.get_budget(period)


@router.post("/budget", status_code=201)
async def add_budget(body: BudgetItem, user=Depends(get_current_user)):
    from master_database import FinanceDB
    bid = FinanceDB.add_budget_item(body.category, body.description,
                                     body.amount_gbp, body.period,
                                     body.budget_type, user.id)
    return {"id": bid, "success": True}


@router.get("/expenses")
async def get_expenses(submitted_by: Optional[int] = None, status: Optional[str] = None,
                       user=Depends(get_current_user)):
    from master_database import FinanceDB
    from permissions import check_permission
    # Non-finance roles only see their own expenses
    if not check_permission(user.role, "expenses", "full"):
        submitted_by = user.id
    return FinanceDB.get_expenses(submitted_by, status)


@router.post("/expenses", status_code=201)
async def submit_expense(body: ExpenseSubmit, user=Depends(get_current_user)):
    from master_database import FinanceDB
    eid = FinanceDB.submit_expense(user.id, body.category, body.description,
                                    body.amount_gbp, body.expense_date,
                                    body.receipt_path)
    return {"id": eid, "success": True}


@router.patch("/expenses/{expense_id}/approve")
async def approve_expense(expense_id: int, user=Depends(get_current_user)):
    from master_database import FinanceDB
    FinanceDB.approve_expense(expense_id, user.id)
    return {"success": True}


@router.get("/grants")
async def get_grants(user=Depends(get_current_user)):
    from master_database import FinanceDB
    return FinanceDB.get_grants()


@router.post("/grants", status_code=201)
async def add_grant(body: GrantCreate, user=Depends(get_current_user)):
    from master_database import FinanceDB
    gid = FinanceDB.add_grant(body.title, body.funder, body.grant_type,
                              body.amount_gbp, body.deadline, user.id)
    return {"id": gid, "success": True}


@router.patch("/grants/{grant_id}")
async def update_grant(grant_id: int, body: GrantUpdate, user=Depends(get_current_user)):
    import sqlite3
    db_path = os.getenv("MASTER_DB_PATH", "aerora_master.db")
    conn = sqlite3.connect(db_path)
    if body.status:
        conn.execute("UPDATE grants_tracker SET status=? WHERE id=?", (body.status, grant_id))
    if body.notes:
        conn.execute("UPDATE grants_tracker SET notes=? WHERE id=?", (body.notes, grant_id))
    conn.commit()
    conn.close()
    return {"success": True}
