"""
Aerora Dynamics — Cloud API
routers/hr_router.py — Team & HR

Wraps aerora_master/master_database.py: HRDB
"""

import os, sys
from typing import Optional, List
from fastapi import APIRouter, Depends
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


class ProfileUpdate(BaseModel):
    job_title:         Optional[str] = ""
    employment_type:   Optional[str] = "full_time"
    start_date:        Optional[str] = ""
    salary_gbp:        Optional[float] = 0
    equity_percent:    Optional[float] = 0
    skills:            Optional[List[str]] = []
    linkedin_url:      Optional[str] = ""
    emergency_contact: Optional[str] = ""

class LeaveRequest(BaseModel):
    leave_type: str
    start_date: str
    end_date:   str
    days_count: float
    reason:     Optional[str] = ""

class OKRCreate(BaseModel):
    quarter:   str
    objective: str
    level:     Optional[str] = "company"

class KRUpdate(BaseModel):
    current_value: float

class RoleCreate(BaseModel):
    role_title:      str
    department:      Optional[str] = ""
    seniority:       Optional[str] = "Mid"
    salary_min_gbp:  Optional[float] = 0
    salary_max_gbp:  Optional[float] = 0
    equity_percent:  Optional[float] = 0
    job_description: Optional[str] = ""
    requirements:    Optional[str] = ""

class CandidateCreate(BaseModel):
    full_name:    str
    email:        Optional[str] = ""
    linkedin_url: Optional[str] = ""
    notes:        Optional[str] = ""


@router.get("/team")
async def get_team(user=Depends(get_current_user)):
    from master_database import HRDB
    return HRDB.get_team_directory()


@router.patch("/team/{user_id}")
async def update_profile(user_id: int, body: ProfileUpdate, user=Depends(get_current_user)):
    from master_database import HRDB
    HRDB.upsert_profile(user_id, **body.dict())
    return {"success": True}


@router.get("/leave")
async def get_leave(user_id: Optional[int] = None, status: Optional[str] = None,
                    user=Depends(get_current_user)):
    from master_database import HRDB
    return HRDB.get_leave_requests(user_id, status)


@router.post("/leave", status_code=201)
async def request_leave(body: LeaveRequest, user=Depends(get_current_user)):
    from master_database import HRDB
    lid = HRDB.request_leave(user.id, body.leave_type, body.start_date,
                              body.end_date, body.days_count, body.reason)
    return {"id": lid, "success": True}


@router.patch("/leave/{leave_id}/approve")
async def approve_leave(leave_id: int, user=Depends(get_current_user)):
    from master_database import HRDB
    HRDB.approve_leave(leave_id, user.id)
    return {"success": True}


@router.get("/okrs")
async def get_okrs(quarter: Optional[str] = None, user=Depends(get_current_user)):
    from master_database import HRDB
    return HRDB.get_okrs(quarter)


@router.post("/okrs", status_code=201)
async def create_okr(body: OKRCreate, user=Depends(get_current_user)):
    from master_database import HRDB
    oid = HRDB.create_okr(body.quarter, body.objective, user.id, body.level)
    return {"id": oid, "success": True}


@router.patch("/okrs/kr/{kr_id}")
async def update_kr(kr_id: int, body: KRUpdate, user=Depends(get_current_user)):
    from master_database import HRDB
    HRDB.update_kr_progress(kr_id, body.current_value)
    return {"success": True}


@router.get("/recruitment")
async def get_roles(user=Depends(get_current_user)):
    from master_database import HRDB
    return HRDB.get_open_roles()


@router.post("/recruitment", status_code=201)
async def create_role(body: RoleCreate, user=Depends(get_current_user)):
    import sqlite3
    db_path = os.getenv("MASTER_DB_PATH", "aerora_master.db")
    conn = sqlite3.connect(db_path)
    cur = conn.execute(
        """INSERT INTO recruitment (role_title, department, seniority,
           salary_min_gbp, salary_max_gbp, equity_percent,
           job_description, requirements, created_by)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (body.role_title, body.department, body.seniority,
         body.salary_min_gbp, body.salary_max_gbp, body.equity_percent,
         body.job_description, body.requirements, user.id)
    )
    conn.commit()
    rid = cur.lastrowid
    conn.close()
    return {"id": rid, "success": True}


@router.get("/recruitment/{role_id}/candidates")
async def get_candidates(role_id: int, user=Depends(get_current_user)):
    import sqlite3
    db_path = os.getenv("MASTER_DB_PATH", "aerora_master.db")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT * FROM candidates WHERE role_id=? ORDER BY created_at DESC", (role_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@router.post("/recruitment/{role_id}/candidates", status_code=201)
async def add_candidate(role_id: int, body: CandidateCreate, user=Depends(get_current_user)):
    from master_database import HRDB
    cid = HRDB.add_candidate(role_id, body.full_name, body.email,
                             body.linkedin_url, body.notes)
    return {"id": cid, "success": True}


@router.patch("/candidates/{candidate_id}")
async def update_candidate(candidate_id: int, body: dict, user=Depends(get_current_user)):
    import sqlite3
    db_path = os.getenv("MASTER_DB_PATH", "aerora_master.db")
    conn = sqlite3.connect(db_path)
    if "stage" in body:
        conn.execute("UPDATE candidates SET stage=? WHERE id=?", (body["stage"], candidate_id))
    if "rating" in body:
        conn.execute("UPDATE candidates SET rating=? WHERE id=?", (body["rating"], candidate_id))
    conn.commit()
    conn.close()
    return {"success": True}
