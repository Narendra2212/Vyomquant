"""
Aerora Dynamics — Cloud API
routers/auth_router.py — Authentication endpoints

POST /login          → returns JWT access token
POST /logout         → invalidates session
GET  /me             → current user info
POST /refresh        → refresh token
POST /change-password
"""

import os, sys
from datetime import datetime, timedelta
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from jose import jwt, JWTError

# ── Path setup ────────────────────────────────────────────────
REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master"),
          os.path.join(REPO, "aerora_dynamics")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from auth import (
    login as db_login, logout as db_logout,
    validate_session, create_user, get_all_users,
    change_password, update_user_role, deactivate_user,
    reactivate_user, admin_reset_password,
)

router  = APIRouter()
bearer  = HTTPBearer(auto_error=False)
SECRET  = os.getenv("JWT_SECRET", "aerora-secret-change-in-production-2024")
ALGO    = "HS256"
EXPIRES = int(os.getenv("JWT_EXPIRES_HOURS", "8"))


# ── Models ────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    email:    str
    password: str

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str


# ── JWT helpers ───────────────────────────────────────────────
def create_jwt(session_token: str, user_id: int) -> str:
    payload = {
        "sub":           str(user_id),
        "session_token": session_token,
        "exp":           datetime.utcnow() + timedelta(hours=EXPIRES),
        "iat":           datetime.utcnow(),
    }
    return jwt.encode(payload, SECRET, algorithm=ALGO)


def decode_jwt(token: str) -> dict:
    try:
        return jwt.decode(token, SECRET, algorithms=[ALGO])
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token.")


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer)
):
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated.")
    payload = decode_jwt(credentials.credentials)
    user = validate_session(payload.get("session_token", ""))
    if not user:
        raise HTTPException(status_code=401, detail="Session expired. Please sign in again.")
    return user


# ── Endpoints ─────────────────────────────────────────────────
@router.post("/login")
async def login(body: LoginRequest):
    result = db_login(body.email, body.password)
    if not result.success:
        raise HTTPException(status_code=401, detail=result.error)
    token = create_jwt(result.token, result.user.id)
    return {
        "access_token": token,
        "token_type":   "bearer",
        "expires_in":   EXPIRES * 3600,
        "user": {
            "id":          result.user.id,
            "full_name":   result.user.full_name,
            "email":       result.user.email,
            "role":        result.user.role,
            "department":  result.user.department,
            "last_login":  result.user.last_login,
            "avatar_initials": result.user.avatar_initials,
        },
    }


@router.post("/logout")
async def logout(user=Depends(get_current_user),
                 credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer)):
    payload = decode_jwt(credentials.credentials)
    db_logout(payload.get("session_token", ""), user)
    return {"success": True}


@router.get("/me")
async def me(user=Depends(get_current_user)):
    return {
        "id":          user.id,
        "full_name":   user.full_name,
        "email":       user.email,
        "role":        user.role,
        "department":  user.department,
        "last_login":  user.last_login,
        "created_at":  user.created_at,
        "is_guest":    user.is_guest,
        "avatar_initials": user.avatar_initials,
    }


@router.post("/change-password")
async def change_pwd(body: ChangePasswordRequest,
                     user=Depends(get_current_user)):
    ok, msg = change_password(user.id, body.old_password, body.new_password)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"success": True, "message": msg}


@router.post("/refresh")
async def refresh(user=Depends(get_current_user)):
    """Issue a fresh token for an already-authenticated user."""
    from auth import _create_session
    new_session = _create_session(user.id)
    token = create_jwt(new_session, user.id)
    return {"access_token": token, "token_type": "bearer", "expires_in": EXPIRES * 3600}


# ── Export dependency for other routers ───────────────────────
# Usage in other routers:
#   from routers.auth_router import get_current_user
