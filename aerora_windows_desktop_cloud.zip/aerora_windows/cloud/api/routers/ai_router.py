"""
Aerora Dynamics — Cloud API
routers/ai_router.py — AI content generation

Wraps aerora_dynamics/ai_content.py: ContentGenerator, VideoBuilder
"""

import os, sys
from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master"), os.path.join(REPO, "aerora_dynamics")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


class TopicRequest(BaseModel):
    topic: str
    count: Optional[int] = 4

class VideoRequest(BaseModel):
    script: str
    avatar_id: Optional[str] = None


@router.get("/content")
async def get_content(type: Optional[str] = None, user=Depends(get_current_user)):
    from database import AIContentDB
    return AIContentDB.get_all(content_type=type)


@router.post("/tweet-thread")
async def generate_tweets(body: TopicRequest, user=Depends(get_current_user)):
    from ai_content import ContentGenerator
    gen = ContentGenerator()
    return gen.generate_tweet_thread(body.topic, num_tweets=body.count)


@router.post("/linkedin-post")
async def generate_linkedin(body: TopicRequest, user=Depends(get_current_user)):
    from ai_content import ContentGenerator
    gen = ContentGenerator()
    return gen.generate_linkedin_post(body.topic)


@router.post("/email-copy")
async def generate_email(body: TopicRequest, user=Depends(get_current_user)):
    from ai_content import ContentGenerator
    gen = ContentGenerator()
    return gen.generate_email_copy(body.topic)


@router.post("/video-script")
async def generate_script(body: TopicRequest, user=Depends(get_current_user)):
    from ai_content import ContentGenerator
    gen = ContentGenerator()
    return gen.generate_video_script(body.topic)


@router.post("/blog-post")
async def generate_blog(body: TopicRequest, user=Depends(get_current_user)):
    from ai_content import ContentGenerator
    gen = ContentGenerator()
    return gen.generate_blog_post(body.topic)


@router.post("/daily-briefing")
async def daily_briefing(user=Depends(get_current_user)):
    from ai_content import ContentGenerator
    gen = ContentGenerator()
    return gen.daily_news_briefing()


@router.post("/build-video")
async def build_video(body: VideoRequest, user=Depends(get_current_user)):
    from ai_content import VideoBuilder
    vb = VideoBuilder()
    return vb.build_video(body.script, avatar_id=body.avatar_id)
