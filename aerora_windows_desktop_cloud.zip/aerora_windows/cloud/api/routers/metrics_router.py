"""
Aerora Dynamics — Cloud API
routers/metrics_router.py — Unified dashboard metrics

GET /snapshot              → combined KPI snapshot (sales + fundos)
GET /timeseries/{metric}   → historical time series for a metric
GET /pipeline               → sales pipeline summary by stage
GET /funnel                 → FundOS investor funnel
"""

import os, sys
from fastapi import APIRouter, Depends, Query
from typing import Optional

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master"), os.path.join(REPO, "aerora_dynamics")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


@router.get("/snapshot")
async def snapshot(user=Depends(get_current_user)):
    """Combined KPI snapshot used by the dashboard's top KPI strip."""
    result = {
        "total_leads": 0, "pipeline_value": 0, "emails_sent_today": 0,
        "social_posts": 0,
    }
    try:
        from database import AnalyticsDB
        result.update(AnalyticsDB.dashboard_snapshot())
    except Exception:
        pass
    return result


@router.get("/timeseries/{metric}")
async def timeseries(metric: str, days: int = Query(30, ge=1, le=365),
                     user=Depends(get_current_user)):
    try:
        from database import AnalyticsDB
        series = AnalyticsDB.get_time_series(metric, days=days)
        return {"metric": metric, "days": days, "data": series}
    except Exception:
        return {"metric": metric, "days": days, "data": []}


@router.get("/pipeline")
async def pipeline_summary(user=Depends(get_current_user)):
    try:
        from database import PipelineDB
        return PipelineDB.pipeline_summary()
    except Exception:
        return {}


@router.get("/funnel")
async def fundos_funnel(user=Depends(get_current_user)):
    """Investor funnel — proxies to FundOS if reachable, else empty."""
    try:
        sys.path.insert(0, os.path.join(REPO, "aerora_master"))
        from integration_bridge import bridge
        metrics = bridge.get_unified_metrics()
        f = metrics.get("fundos", {})
        return {
            "total_discovered":  f.get("investors_total", 0),
            "total_qualified":   f.get("investors_qualified", 0),
            "total_contacted":   f.get("investors_contacted", 0),
            "total_replied":     f.get("investors_replied", 0),
            "total_meetings":    f.get("investors_meetings", 0),
            "total_term_sheets": f.get("term_sheets", 0),
        }
    except Exception:
        return {
            "total_discovered": 0, "total_qualified": 0, "total_contacted": 0,
            "total_replied": 0, "total_meetings": 0, "total_term_sheets": 0,
        }
