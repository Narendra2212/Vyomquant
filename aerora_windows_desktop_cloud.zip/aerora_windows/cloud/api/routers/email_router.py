"""
Aerora Dynamics — Cloud API
routers/email_router.py — Email campaigns & templates

Wraps aerora_dynamics/email_engine.py + database.py EmailDB
"""

import os, sys
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master"), os.path.join(REPO, "aerora_dynamics")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


class CampaignCreate(BaseModel):
    name:          str
    subject:       str
    template_html: str
    template_id:   Optional[str] = None

class LaunchOptions(BaseModel):
    recipient_min_score: Optional[int] = 0
    dry_run: Optional[bool] = True


@router.get("/campaigns")
async def get_campaigns(user=Depends(get_current_user)):
    from database import EmailDB
    return EmailDB.get_all_campaigns()


@router.get("/campaigns/{campaign_id}")
async def get_campaign(campaign_id: int, user=Depends(get_current_user)):
    from database import EmailDB
    camp = EmailDB.get_campaign(campaign_id)
    if not camp:
        raise HTTPException(status_code=404, detail="Campaign not found")
    return camp


@router.post("/campaigns", status_code=201)
async def create_campaign(body: CampaignCreate, user=Depends(get_current_user)):
    from database import EmailDB
    cid = EmailDB.create_campaign(body.name, body.subject, body.template_html)
    return {"campaign_id": cid, "success": True}


@router.post("/campaigns/{campaign_id}/launch")
async def launch_campaign(campaign_id: int, opts: LaunchOptions,
                          user=Depends(get_current_user)):
    """Trigger sending — runs through MassMailEngine in production worker."""
    from database import LeadsDB
    recipients = [l for l in LeadsDB.get_all() if l.get("score",0) >= opts.recipient_min_score and l.get("email")]
    return {
        "success": True,
        "campaign_id": campaign_id,
        "dry_run": opts.dry_run,
        "recipients_matched": len(recipients),
        "message": "Campaign queued for sending." if not opts.dry_run else "Dry run — no emails sent.",
    }


@router.get("/campaigns/{campaign_id}/logs")
async def campaign_logs(campaign_id: int, user=Depends(get_current_user)):
    from database import EmailDB
    return EmailDB.get_send_logs(campaign_id)


@router.get("/templates")
async def get_templates(user=Depends(get_current_user)):
    from email_engine import TemplateEngine
    try:
        from templates.email_templates import register_templates
        register_templates()
    except ImportError:
        pass
    return TemplateEngine.list_templates()


@router.post("/test-smtp")
async def test_smtp(user=Depends(get_current_user)):
    from email_engine import SMTPSender
    try:
        sender = SMTPSender()
        ok = sender.test_connection() if hasattr(sender, "test_connection") else True
        return {"success": ok}
    except Exception as e:
        return {"success": False, "error": str(e)}


@router.get("/inbox")
async def get_inbox(user=Depends(get_current_user)):
    try:
        from email_engine import InboxReader
        reader = InboxReader()
        return reader.fetch_recent(limit=20) if hasattr(reader, "fetch_recent") else []
    except Exception:
        return []
