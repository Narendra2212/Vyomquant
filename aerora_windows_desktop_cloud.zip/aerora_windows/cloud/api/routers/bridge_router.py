"""
Aerora Dynamics — Cloud API
routers/bridge_router.py — Integration Bridge Control

Wraps aerora_master/integration_bridge.py
"""

import os, sys
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


class SyncRequest(BaseModel):
    dry_run: bool = True


def _require_bridge_access(user):
    from permissions import check_permission
    if not check_permission(user.role, "user_management", "view"):
        raise HTTPException(status_code=403, detail="Admin/Executive access required")


@router.get("/status")
async def status(user=Depends(get_current_user)):
    from integration_bridge import bridge
    conn = bridge.check_connections()
    return {
        "fundos_api":     conn.get("fundos_api", False),
        "sales_db":       conn.get("sales_db", False),
        "bridge_db":      conn.get("bridge_db", False),
        "api_online":     True,
        "bridge_running": True,
        "email_ok":       True,
        "ai_ok":          True,
    }


@router.post("/sync")
async def run_sync(body: SyncRequest, user=Depends(get_current_user)):
    _require_bridge_access(user)
    from integration_bridge import bridge
    results = bridge.full_sync(dry_run=body.dry_run)
    return {
        action: {
            "success":          r.success,
            "records_affected": r.records_affected,
            "details":          r.details,
            "error":            r.error,
        }
        for action, r in results.items()
    }


@router.get("/events")
async def get_events(limit: int = 50, user=Depends(get_current_user)):
    from integration_bridge import bridge
    return bridge.get_bridge_events(limit)


@router.get("/contacts")
async def get_contact_map(user=Depends(get_current_user)):
    from integration_bridge import bridge
    return bridge.get_contact_map()
