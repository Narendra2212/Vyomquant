"""
Aerora Dynamics — Cloud API
routers/investors_router.py — FundOS Proxy

Proxies requests to the FundOS FastAPI backend through the
Integration Bridge so the Electron app only needs ONE API endpoint
(the Aerora Cloud API) regardless of whether FundOS lives on the
same server or a different one.

Mounted at /api/v1 — so paths become:
  /api/v1/investors
  /api/v1/crm
  /api/v1/grants
  /api/v1/analytics/funnel
  /api/v1/analytics/summary
  /api/v1/outreach/campaigns
  /api/v1/milestones
"""

import os, sys
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


class InvestorUpdate(BaseModel):
    status: Optional[str] = None
    notes:  Optional[str] = None

class CRMUpdate(BaseModel):
    stage: Optional[str] = None
    notes: Optional[str] = None

class OutreachSend(BaseModel):
    investor_ids: list
    template_id:  str

class MilestoneUpdate(BaseModel):
    status: str


def _get_bridge():
    from integration_bridge import bridge
    return bridge


@router.get("/investors")
async def get_investors(min_score: float = 0, limit: int = 100,
                        user=Depends(get_current_user)):
    bridge = _get_bridge()
    if not bridge._fundos.is_reachable():
        return {"items": [], "fundos_offline": True}
    items = bridge._fundos.get_investors(min_score=min_score, limit=limit)
    return {"items": items, "count": len(items)}


@router.get("/investors/{investor_id}")
async def get_investor(investor_id: str, user=Depends(get_current_user)):
    bridge = _get_bridge()
    result = bridge._fundos.get(f"/api/v1/investors/{investor_id}")
    if not result:
        raise HTTPException(status_code=404, detail="Investor not found or FundOS offline")
    return result


@router.patch("/investors/{investor_id}")
async def update_investor(investor_id: str, body: InvestorUpdate,
                          user=Depends(get_current_user)):
    bridge = _get_bridge()
    result = bridge._fundos.post(f"/api/v1/investors/{investor_id}/update",
                                  body.dict(exclude_none=True))
    return result or {"success": False, "error": "FundOS unreachable"}


@router.get("/crm")
async def get_crm(user=Depends(get_current_user)):
    bridge = _get_bridge()
    return {"records": bridge._fundos.get_crm_pipeline()}


@router.patch("/crm/{record_id}")
async def update_crm(record_id: str, body: CRMUpdate, user=Depends(get_current_user)):
    bridge = _get_bridge()
    result = bridge._fundos.post(f"/api/v1/crm/{record_id}/update",
                                  body.dict(exclude_none=True))
    return result or {"success": False, "error": "FundOS unreachable"}


@router.get("/grants")
async def get_grants(status: str = "active", user=Depends(get_current_user)):
    bridge = _get_bridge()
    return {"items": bridge._fundos.get_grants(status)}


@router.get("/analytics/summary")
async def analytics_summary(user=Depends(get_current_user)):
    bridge = _get_bridge()
    return bridge._fundos.get_analytics() or {}


@router.get("/analytics/funnel")
async def analytics_funnel(user=Depends(get_current_user)):
    bridge = _get_bridge()
    return bridge._fundos.get_funnel() or {}


@router.get("/outreach/campaigns")
async def outreach_campaigns(user=Depends(get_current_user)):
    bridge = _get_bridge()
    return {"items": bridge._fundos.get_outreach_campaigns()}


@router.post("/outreach/send")
async def send_outreach(body: OutreachSend, user=Depends(get_current_user)):
    bridge = _get_bridge()
    result = bridge._fundos.post("/api/v1/outreach/send", body.dict())
    return result or {"success": False, "error": "FundOS unreachable"}


@router.get("/milestones")
async def get_milestones(user=Depends(get_current_user)):
    bridge = _get_bridge()
    return bridge._fundos.get_milestones()


@router.patch("/milestones/{milestone_id}")
async def update_milestone(milestone_id: str, body: MilestoneUpdate,
                           user=Depends(get_current_user)):
    bridge = _get_bridge()
    result = bridge._fundos.post(f"/api/v1/milestones/{milestone_id}/update",
                                  {"status": body.status})
    return result or {"success": False, "error": "FundOS unreachable"}
