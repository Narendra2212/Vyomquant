"""
Aerora Dynamics — Cloud API
routers/leads_router.py — Leads & CRM Pipeline endpoints

Wraps aerora_dynamics/database.py: LeadsDB, PipelineDB
"""

import os, sys, json
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import io, csv

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master"), os.path.join(REPO, "aerora_dynamics")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


# ── Models ────────────────────────────────────────────────────
class LeadCreate(BaseModel):
    company_name: str
    email:        Optional[str] = None
    contact_name: Optional[str] = None
    phone:        Optional[str] = None
    linkedin_url: Optional[str] = None
    industry:     Optional[str] = None
    location:     Optional[str] = None
    score:        Optional[int] = 0
    source:       Optional[str] = "manual"
    tags:         Optional[List[str]] = []

class LeadUpdate(BaseModel):
    status: Optional[str] = None
    score:  Optional[int] = None

class DealCreate(BaseModel):
    lead_id:      int
    stage:        Optional[str] = "Discovered"
    deal_value:   Optional[float] = 0
    probability:  Optional[int] = 10
    assigned_to:  Optional[str] = None
    next_action:  Optional[str] = None

class DealUpdate(BaseModel):
    deal_value:  Optional[float] = None
    probability: Optional[int]   = None
    next_action: Optional[str]   = None

class StageUpdate(BaseModel):
    stage: str


def _check_perm(user, module, action):
    """Helper: raise 403 if role lacks permission."""
    try:
        sys.path.insert(0, os.path.join(REPO, "aerora_master"))
        from permissions import check_permission
        if not check_permission(user.role, module, action):
            raise HTTPException(status_code=403, detail=f"No permission for {module}")
    except ImportError:
        pass


# ── Leads endpoints ───────────────────────────────────────────
@router.get("")
async def get_leads(q: Optional[str] = None, min_score: int = 0,
                     status: Optional[str] = None,
                     user=Depends(get_current_user)):
    _check_perm(user, "leads", "view")
    from database import LeadsDB
    if q:
        leads = LeadsDB.search(q)
    else:
        leads = LeadsDB.get_all(status=status)
    leads = [l for l in leads if l.get("score", 0) >= min_score]
    return {"leads": leads, "count": len(leads)}


@router.get("/{lead_id}")
async def get_lead(lead_id: int, user=Depends(get_current_user)):
    _check_perm(user, "leads", "view")
    from database import LeadsDB
    lead = LeadsDB.get_by_id(lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    return lead


@router.post("", status_code=201)
async def create_lead(body: LeadCreate, user=Depends(get_current_user)):
    _check_perm(user, "leads", "create")
    from database import LeadsDB
    lead_id = LeadsDB.insert(**body.dict())
    if not lead_id:
        raise HTTPException(status_code=409, detail="Duplicate lead (email already exists)")
    return {"lead_id": lead_id, "success": True}


@router.patch("/{lead_id}")
async def update_lead(lead_id: int, body: LeadUpdate, user=Depends(get_current_user)):
    _check_perm(user, "leads", "edit")
    from database import LeadsDB
    if body.status:
        LeadsDB.update_status(lead_id, body.status)
    if body.score is not None:
        LeadsDB.update_score(lead_id, body.score)
    return {"success": True}


@router.delete("/{lead_id}")
async def delete_lead(lead_id: int, user=Depends(get_current_user)):
    _check_perm(user, "leads", "delete")
    from database import LeadsDB
    LeadsDB.delete(lead_id)
    return {"success": True}


@router.get("/search")
async def search_leads(q: str, user=Depends(get_current_user)):
    from database import LeadsDB
    return {"leads": LeadsDB.search(q)}


@router.get("/export")
async def export_leads(user=Depends(get_current_user)):
    _check_perm(user, "leads", "view")
    from database import LeadsDB
    leads = LeadsDB.get_all()
    output = io.StringIO()
    if leads:
        writer = csv.DictWriter(output, fieldnames=leads[0].keys())
        writer.writeheader()
        writer.writerows(leads)
    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=leads_export.csv"},
    )


@router.post("/import")
async def import_leads(file: UploadFile = File(...), user=Depends(get_current_user)):
    _check_perm(user, "leads", "create")
    contents = await file.read()
    tmp_path = f"/tmp/{file.filename}"
    with open(tmp_path, "wb") as f:
        f.write(contents)
    from utils import import_leads_from_csv
    stats = import_leads_from_csv(tmp_path)
    return stats


@router.post("/{lead_id}/score")
async def rescore_lead(lead_id: int, user=Depends(get_current_user)):
    from database import LeadsDB
    from scraper import LeadScorer, ScrapedLead
    lead = LeadsDB.get_by_id(lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    scored = LeadScorer.score(ScrapedLead(
        company_name=lead.get("company_name",""), email=lead.get("email",""),
        industry=lead.get("industry",""), location=lead.get("location",""),
    ))
    LeadsDB.update_score(lead_id, scored)
    return {"lead_id": lead_id, "new_score": scored}


@router.post("/scrape")
async def run_scraper(config: dict, user=Depends(get_current_user)):
    """Trigger a lead-scraping job (runs async in background in production)."""
    _check_perm(user, "leads", "create")
    return {"success": True, "message": "Scrape job queued.", "config": config}


# ── CRM Pipeline endpoints (separate router but same file for simplicity) ─
crm_router = APIRouter()

@crm_router.get("")
async def get_pipeline(stage: Optional[str] = None, user=Depends(get_current_user)):
    _check_perm(user, "crm_pipeline", "view")
    from database import PipelineDB
    deals = PipelineDB.get_deals_by_stage(stage) if stage else PipelineDB.get_all_deals()
    return {"deals": deals, "count": len(deals)}


@crm_router.post("", status_code=201)
async def create_deal(body: DealCreate, user=Depends(get_current_user)):
    _check_perm(user, "crm_pipeline", "create")
    from database import PipelineDB
    deal_id = PipelineDB.add_deal(**body.dict())
    return {"deal_id": deal_id, "success": True}


@crm_router.patch("/{deal_id}")
async def update_deal(deal_id: int, body: DealUpdate, user=Depends(get_current_user)):
    _check_perm(user, "crm_pipeline", "edit")
    from database import PipelineDB
    PipelineDB.update_deal(deal_id, **{k: v for k, v in body.dict().items() if v is not None})
    return {"success": True}


@crm_router.patch("/{deal_id}/stage")
async def move_deal(deal_id: int, body: StageUpdate, user=Depends(get_current_user)):
    _check_perm(user, "crm_pipeline", "edit")
    from database import PipelineDB
    PipelineDB.move_stage(deal_id, body.stage)
    return {"success": True}


@crm_router.delete("/{deal_id}")
async def delete_deal(deal_id: int, user=Depends(get_current_user)):
    _check_perm(user, "crm_pipeline", "delete")
    from database import PipelineDB
    return {"success": True}


@crm_router.get("/summary")
async def pipeline_summary(user=Depends(get_current_user)):
    from database import PipelineDB
    return PipelineDB.pipeline_summary()
