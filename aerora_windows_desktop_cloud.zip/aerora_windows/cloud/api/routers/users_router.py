"""
Aerora Dynamics — Cloud API
routers/users_router.py — Platform Users, Audit Log, Notifications

Wraps aerora_master/auth.py + master_database.py NotificationDB
"""

import os, sys
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


class UserCreate(BaseModel):
    full_name:  str
    email:      str
    password:   str
    role:       str
    department: Optional[str] = ""
    is_guest:   Optional[bool] = False
    guest_days: Optional[int] = 30

class RoleUpdate(BaseModel):
    role: str

class PasswordReset(BaseModel):
    password: str


def _require_admin(user):
    from permissions import check_permission
    if not check_permission(user.role, "user_management", "full"):
        raise HTTPException(status_code=403, detail="Admin access required")


@router.get("/users")
async def get_users(user=Depends(get_current_user)):
    from auth import get_all_users
    from permissions import check_permission
    if not check_permission(user.role, "user_management", "view"):
        raise HTTPException(status_code=403, detail="No permission")
    return get_all_users()


@router.post("/users", status_code=201)
async def create_user_endpoint(body: UserCreate, user=Depends(get_current_user)):
    _require_admin(user)
    from auth import create_user
    ok, msg = create_user(body.full_name, body.email, body.password,
                          body.role, body.department, body.is_guest,
                          body.guest_days, user.id)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"success": True, "message": msg}


@router.patch("/users/{user_id}/role")
async def update_role(user_id: int, body: RoleUpdate, user=Depends(get_current_user)):
    _require_admin(user)
    from auth import update_user_role
    ok, msg = update_user_role(user_id, body.role, user.id)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"success": True, "message": msg}


@router.patch("/users/{user_id}/deactivate")
async def deactivate(user_id: int, user=Depends(get_current_user)):
    _require_admin(user)
    from auth import deactivate_user
    ok, msg = deactivate_user(user_id, user.id)
    return {"success": ok, "message": msg}


@router.patch("/users/{user_id}/reactivate")
async def reactivate(user_id: int, user=Depends(get_current_user)):
    _require_admin(user)
    from auth import reactivate_user
    ok, msg = reactivate_user(user_id, user.id)
    return {"success": ok, "message": msg}


@router.patch("/users/{user_id}/reset-password")
async def reset_password(user_id: int, body: PasswordReset,
                         user=Depends(get_current_user)):
    _require_admin(user)
    from auth import admin_reset_password
    ok, msg = admin_reset_password(user_id, body.password, user.id)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"success": True, "message": msg}


@router.get("/audit-log")
async def get_audit(limit: int = 200, module: Optional[str] = None,
                    user=Depends(get_current_user)):
    from permissions import check_permission
    if not check_permission(user.role, "audit_log", "view"):
        raise HTTPException(status_code=403, detail="No permission")
    from auth import get_audit_log
    return get_audit_log(module=module, limit=limit)


@router.get("/notifications")
async def get_notifications(user=Depends(get_current_user)):
    from master_database import NotificationDB
    return NotificationDB.get_unread(user.id)


@router.patch("/notifications/{notification_id}/read")
async def mark_read(notification_id: int, user=Depends(get_current_user)):
    from master_database import NotificationDB
    NotificationDB.mark_read(notification_id)
    return {"success": True}
