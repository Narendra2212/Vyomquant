"""
Aerora Dynamics — Cloud API
routers/compliance_router.py — Compliance & IP

Wraps aerora_master/master_database.py: ComplianceDB
"""

import os, sys
from typing import Optional, List
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel

REPO = os.path.join(os.path.dirname(__file__), "..", "..", "..", "..")
for p in [os.path.join(REPO, "aerora_master")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from routers.auth_router import get_current_user

router = APIRouter()


class IPCreate(BaseModel):
    title:       str
    ip_type:     str
    description: str
    inventors:   Optional[List[int]] = []

class IPUpdate(BaseModel):
    status: str

class NDACreate(BaseModel):
    counterparty: str
    nda_type:     str
    purpose:      str
    signed_date:  str
    expiry_date:  str
    signed_by:    int

class RegulatoryCreate(BaseModel):
    title:            str
    reg_type:         str
    expiry_date:      str
    reference_number: Optional[str] = ""
    issuing_body:     Optional[str] = ""
    jurisdiction:     Optional[str] = "UK"

class RegulatoryUpdate(BaseModel):
    status: str

class CertCreate(BaseModel):
    title:       str
    cert_type:   str
    standard:    str
    issued_to:   str
    issuer:      str
    issue_date:  str
    expiry_date: str


@router.get("/ip")
async def get_ip(user=Depends(get_current_user)):
    from master_database import ComplianceDB
    return ComplianceDB.get_ip_log()


@router.post("/ip", status_code=201)
async def add_ip(body: IPCreate, user=Depends(get_current_user)):
    from master_database import ComplianceDB
    iid = ComplianceDB.add_ip(body.title, body.ip_type, body.description,
                              body.inventors, user.id)
    return {"id": iid, "success": True}


@router.patch("/ip/{ip_id}")
async def update_ip(ip_id: int, body: IPUpdate, user=Depends(get_current_user)):
    import sqlite3
    db_path = os.getenv("MASTER_DB_PATH", "aerora_master.db")
    conn = sqlite3.connect(db_path)
    conn.execute("UPDATE ip_log SET status=? WHERE id=?", (body.status, ip_id))
    conn.commit()
    conn.close()
    return {"success": True}


@router.get("/ndas")
async def get_ndas(user=Depends(get_current_user)):
    from master_database import ComplianceDB
    return ComplianceDB.get_ndas()


@router.post("/ndas", status_code=201)
async def add_nda(body: NDACreate, user=Depends(get_current_user)):
    from master_database import ComplianceDB
    nid = ComplianceDB.add_nda(body.counterparty, body.nda_type, body.purpose,
                               body.signed_date, body.expiry_date,
                               body.signed_by, user.id)
    return {"id": nid, "success": True}


@router.get("/regulatory")
async def get_regulatory(user=Depends(get_current_user)):
    from master_database import ComplianceDB
    return ComplianceDB.get_regulatory()


@router.post("/regulatory", status_code=201)
async def add_regulatory(body: RegulatoryCreate, user=Depends(get_current_user)):
    from master_database import ComplianceDB
    rid = ComplianceDB.add_regulatory(body.title, body.reg_type, body.expiry_date,
                                      user.id, body.reference_number,
                                      body.issuing_body, body.jurisdiction)
    return {"id": rid, "success": True}


@router.patch("/regulatory/{reg_id}")
async def update_regulatory(reg_id: int, body: RegulatoryUpdate,
                            user=Depends(get_current_user)):
    import sqlite3
    db_path = os.getenv("MASTER_DB_PATH", "aerora_master.db")
    conn = sqlite3.connect(db_path)
    conn.execute("UPDATE regulatory SET status=? WHERE id=?", (body.status, reg_id))
    conn.commit()
    conn.close()
    return {"success": True}


@router.get("/expiring")
async def expiring(days: int = Query(60, ge=1, le=365), user=Depends(get_current_user)):
    from master_database import ComplianceDB
    return ComplianceDB.expiring_soon(days)


@router.get("/certs")
async def get_certs(user=Depends(get_current_user)):
    from master_database import ComplianceDB
    return ComplianceDB.get_certs()


@router.post("/certs", status_code=201)
async def add_cert(body: CertCreate, user=Depends(get_current_user)):
    from master_database import ComplianceDB
    cid = ComplianceDB.add_cert(body.title, body.cert_type, body.standard,
                                body.issued_to, body.issuer, body.issue_date,
                                body.expiry_date, user.id)
    return {"id": cid, "success": True}
