"""
============================================================
Aerora Dynamics — Cloud Backend
cloud/api/main.py — Unified FastAPI Application

Single cloud API that serves ALL platform modules:
  /api/v1/auth/        Authentication & user management
  /api/v1/metrics/     Unified KPI dashboard data
  /api/v1/leads/       B2B leads
  /api/v1/pipeline/    CRM deal pipeline
  /api/v1/email/       Email campaigns & templates
  /api/v1/social/      Social media posts & analytics
  /api/v1/ai/          AI content generation
  /api/v1/build/       Build ops, BOM, issues, milestones
  /api/v1/hr/          Team, leave, OKRs, recruitment
  /api/v1/finance/     Runway, budget, expenses, grants
  /api/v1/compliance/  IP, NDAs, regulatory, certs
  /api/v1/investors/   FundOS investor pipeline
  /api/v1/crm/         FundOS CRM
  /api/v1/grants/      FundOS grants
  /api/v1/analytics/   FundOS analytics
  /api/v1/outreach/    FundOS outreach campaigns
  /api/v1/milestones/  FundOS milestones
  /api/v1/users/       Platform user management
  /api/v1/notifications/ User notifications
  /api/v1/audit-log/   Immutable audit trail
  /api/v1/bridge/      FundOS integration bridge
  /api/health          Health check

Deploy on any cloud:
  Railway, Render, AWS EC2, Azure, GCP, Fly.io
  docker-compose -f docker-compose.prod.yml up -d
============================================================
"""

import os
import sys
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from loguru import logger

# ── Add project roots to path ─────────────────────────────────
CLOUD_DIR = os.path.dirname(__file__)
REPO_ROOT  = os.path.dirname(os.path.dirname(CLOUD_DIR))
for p in [REPO_ROOT,
          os.path.join(REPO_ROOT, "aerora_master"),
          os.path.join(REPO_ROOT, "aerora_dynamics"),
          os.path.join(REPO_ROOT, "aerora_funding_app", "backend")]:
    if p not in sys.path:
        sys.path.insert(0, p)

# Make routers importable as "routers.X"
sys.path.insert(0, CLOUD_DIR)

# ── Routers ───────────────────────────────────────────────────
from routers.auth_router        import router as auth_router
from routers.metrics_router     import router as metrics_router
from routers.leads_router       import router as leads_router, crm_router
from routers.email_router       import router as email_router
from routers.social_router      import router as social_router
from routers.ai_router          import router as ai_router
from routers.build_router       import router as build_router
from routers.hr_router          import router as hr_router
from routers.finance_router     import router as finance_router
from routers.compliance_router  import router as compliance_router
from routers.investors_router   import router as investors_router
from routers.users_router       import router as users_router
from routers.bridge_router      import router as bridge_router


# ── DB init ───────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialise databases on startup."""
    logger.info("Aerora Cloud API starting…")
    try:
        os.environ.setdefault("DATABASE_PATH",
            os.path.join(REPO_ROOT, "aerora_dynamics", "aerora_dynamics.db"))
        os.environ.setdefault("MASTER_DB_PATH",
            os.path.join(REPO_ROOT, "aerora_master", "aerora_master.db"))
        os.environ.setdefault("BRIDGE_DB_PATH",
            os.path.join(REPO_ROOT, "aerora_master", "aerora_bridge.db"))

        # Init sales DB
        sys.path.insert(0, os.path.join(REPO_ROOT, "aerora_dynamics"))
        from database import init_database
        init_database()

        # Init master DB
        sys.path.insert(0, os.path.join(REPO_ROOT, "aerora_master"))
        from auth import init_auth_tables
        from master_database import init_all_tables
        init_auth_tables()
        init_all_tables()

        logger.success("All databases initialised.")
    except Exception as e:
        logger.error(f"DB init error: {e}")
    yield
    logger.info("Aerora Cloud API shutting down.")


# ── App factory ───────────────────────────────────────────────
app = FastAPI(
    title="Aerora Dynamics Cloud API",
    description="Unified backend for the Aerora Dynamics Command Platform",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# ── Middleware ────────────────────────────────────────────────
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "app://.",                              # Electron (production)
        "http://localhost:3000",                # React dev server
        "http://localhost:8501",                # Streamlit
        "https://platform.aerora-dynamics.com", # Production web
        os.getenv("ALLOWED_ORIGIN", ""),
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Mount all routers ─────────────────────────────────────────
app.include_router(auth_router,       prefix="/api/v1/auth",          tags=["Auth"])
app.include_router(metrics_router,    prefix="/api/v1/metrics",        tags=["Metrics"])
app.include_router(leads_router,      prefix="/api/v1/leads",          tags=["Leads"])
app.include_router(crm_router,        prefix="/api/v1/pipeline",       tags=["CRM Pipeline"])
app.include_router(email_router,      prefix="/api/v1/email",          tags=["Email"])
app.include_router(social_router,     prefix="/api/v1/social",         tags=["Social"])
app.include_router(ai_router,         prefix="/api/v1/ai",             tags=["AI"])
app.include_router(build_router,      prefix="/api/v1/build",          tags=["Build"])
app.include_router(hr_router,         prefix="/api/v1/hr",             tags=["HR"])
app.include_router(finance_router,    prefix="/api/v1/finance",        tags=["Finance"])
app.include_router(compliance_router, prefix="/api/v1/compliance",     tags=["Compliance"])
app.include_router(investors_router,  prefix="/api/v1",                tags=["Fundraising"])
app.include_router(users_router,      prefix="/api/v1",                tags=["Users"])
app.include_router(bridge_router,     prefix="/api/v1/bridge",         tags=["Bridge"])

# ── Health & root ─────────────────────────────────────────────
@app.get("/api/health", tags=["System"])
async def health():
    from datetime import datetime
    try:
        sys.path.insert(0, os.path.join(REPO_ROOT, "aerora_dynamics"))
        from database import LeadsDB
        leads = LeadsDB.count()
        return {
            "status":    "healthy",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "version":   "2.0.0",
            "db_leads":  leads,
        }
    except Exception as e:
        return JSONResponse(status_code=503,
            content={"status": "unhealthy", "error": str(e)})

@app.get("/", include_in_schema=False)
async def root():
    return {
        "name":    "Aerora Dynamics Cloud API",
        "version": "2.0.0",
        "docs":    "/docs",
        "health":  "/api/health",
    }

# ── Run directly ──────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=os.getenv("HOST", "0.0.0.0"),
        port=int(os.getenv("PORT", "8080")),
        reload=os.getenv("ENV", "production") == "development",
        workers=int(os.getenv("WORKERS", "2")),
        log_level="info",
    )
