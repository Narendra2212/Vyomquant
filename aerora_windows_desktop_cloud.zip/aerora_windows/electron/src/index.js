// CRA requires the entry point at src/index.js — this re-exports
// the actual renderer entry so our organised src/renderer/ structure
// still works without ejecting or adding craco/webpack overrides.
import './renderer/index.js';
