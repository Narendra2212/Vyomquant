/**
 * Aerora Dynamics — Windows Desktop App
 * src/main/preload.js — Secure Electron Preload Bridge
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('aerora', {
  window: {
    minimize:    () => ipcRenderer.send('window:minimize'),
    maximize:    () => ipcRenderer.send('window:maximize'),
    close:       () => ipcRenderer.send('window:close'),
    isMaximized: () => ipcRenderer.sendSync('window:isMaximized'),
    onMaximize:  (cb) => ipcRenderer.on('window:maximized', (_, v) => cb(v)),
  },
  store: {
    get:    (key)         => ipcRenderer.invoke('store:get', key),
    set:    (key, value)  => ipcRenderer.invoke('store:set', key, value),
    delete: (key)         => ipcRenderer.invoke('store:delete', key),
    getAll: ()            => ipcRenderer.invoke('store:getAll'),
  },
  auth: {
    saveToken:  (token) => ipcRenderer.invoke('auth:saveToken', token),
    getToken:   ()      => ipcRenderer.invoke('auth:getToken'),
    clearToken: ()      => ipcRenderer.invoke('auth:clearToken'),
    notifyChange: (data)=> ipcRenderer.send('auth:changed', data),
  },
  app: {
    getVersion:  () => ipcRenderer.invoke('app:getVersion'),
    getApiUrl:   () => ipcRenderer.invoke('app:getApiUrl'),
    setApiUrl:   (url) => ipcRenderer.invoke('app:setApiUrl', url),
    getPlatform: () => ipcRenderer.invoke('app:getPlatform'),
  },
  dialog: {
    openFile: (options) => ipcRenderer.invoke('dialog:openFile', options),
    saveFile: (options) => ipcRenderer.invoke('dialog:saveFile', options),
  },
  notify: (title, body) => ipcRenderer.send('notify', { title, body }),
  openExternal: (url) => ipcRenderer.send('shell:openExternal', url),
  onNavigate: (cb) => ipcRenderer.on('navigate', (_, route) => cb(route)),
  updater: {
    checkNow:       ()   => ipcRenderer.send('updater:checkNow'),
    onChecking:     (cb) => ipcRenderer.on('updater:checking',      () => cb()),
    onAvailable:    (cb) => ipcRenderer.on('updater:available',     (_, i) => cb(i)),
    onNotAvailable: (cb) => ipcRenderer.on('updater:not-available', () => cb()),
    onProgress:     (cb) => ipcRenderer.on('updater:progress',      (_, p) => cb(p)),
    onDownloaded:   (cb) => ipcRenderer.on('updater:downloaded',    (_, i) => cb(i)),
    onError:        (cb) => ipcRenderer.on('updater:error',         (_, e) => cb(e)),
  },
  theme: {
    get:      () => ipcRenderer.invoke('theme:get'),
    onChange: (cb) => ipcRenderer.on('theme:changed', (_, t) => cb(t)),
  },
});
