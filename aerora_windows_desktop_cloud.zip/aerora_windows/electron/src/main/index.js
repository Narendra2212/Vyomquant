/**
 * Aerora Dynamics — Windows Desktop App
 * src/main/index.js — Electron Main Process
 */

const {
  app, BrowserWindow, Tray, Menu, shell,
  ipcMain, nativeTheme, dialog, Notification,
  session,
} = require('electron');
const path        = require('path');
const Store       = require('electron-store');
const { autoUpdater } = require('electron-updater');

const isDev       = process.env.NODE_ENV === 'development';
const CLOUD_API   = process.env.AERORA_API_URL || 'https://api.aerora-dynamics.com';
const ICON_PATH   = path.join(__dirname, '../../assets/aerora.ico');

const store = new Store({
  name: 'aerora-settings',
  defaults: {
    windowBounds:  { width: 1440, height: 900 },
    windowMaximized: true,
    apiUrl:        CLOUD_API,
    authToken:     null,
    lastUser:      null,
    theme:         'dark',
    notifications: true,
    startMinimized:false,
  },
  encryptionKey: 'aerora-secure-store-key-2024',
});

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); process.exit(0); }

let mainWindow  = null;
let tray        = null;
let isQuitting  = false;

function createMainWindow() {
  const { width, height } = store.get('windowBounds');

  mainWindow = new BrowserWindow({
    width, height, minWidth: 1024, minHeight: 700,
    title: 'Aerora Dynamics', icon: ICON_PATH, show: false,
    frame: false, titleBarStyle: 'hidden',
    backgroundColor: '#050e1a',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false,
      webSecurity: true,
    },
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  } else {
    mainWindow.loadFile(path.join(__dirname, '../../build/index.html'));
  }

  mainWindow.once('ready-to-show', () => {
    if (store.get('windowMaximized')) mainWindow.maximize();
    if (!store.get('startMinimized')) { mainWindow.show(); mainWindow.focus(); }
  });

  mainWindow.on('resize', () => {
    if (!mainWindow.isMaximized()) store.set('windowBounds', mainWindow.getBounds());
  });
  mainWindow.on('maximize',   () => store.set('windowMaximized', true));
  mainWindow.on('unmaximize', () => store.set('windowMaximized', false));

  mainWindow.on('close', (e) => {
    if (!isQuitting) {
      e.preventDefault();
      mainWindow.hide();
      if (Notification.isSupported()) {
        new Notification({
          title: 'Aerora Dynamics',
          body:  'Running in the system tray. Click the tray icon to reopen.',
          icon:  ICON_PATH,
        }).show();
      }
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  return mainWindow;
}

function createTray() {
  tray = new Tray(ICON_PATH);
  tray.setToolTip('Aerora Dynamics Platform');

  const buildMenu = (isLoggedIn = false, userName = '') => Menu.buildFromTemplate([
    { label: 'Aerora Dynamics', enabled: false },
    { type: 'separator' },
    { label: isLoggedIn ? `Signed in as ${userName}` : 'Not signed in', enabled: false },
    { type: 'separator' },
    { label: '🏠 Open Dashboard',  click: () => showWindow() },
    { label: '📡 Sales & CRM',     click: () => showWindow('/sales'),       enabled: isLoggedIn },
    { label: '💰 Fundraising',     click: () => showWindow('/fundraising'), enabled: isLoggedIn },
    { label: '🔧 Build & Ops',     click: () => showWindow('/build'),       enabled: isLoggedIn },
    { type: 'separator' },
    { label: '⚙️ Settings',        click: () => showWindow('/settings') },
    { label: '🔄 Check for Updates', click: () => autoUpdater.checkForUpdatesAndNotify() },
    { type: 'separator' },
    { label: '❌ Quit Aerora', click: () => { isQuitting = true; app.quit(); } },
  ]);

  tray.setContextMenu(buildMenu());
  tray.on('double-click', () => showWindow());

  ipcMain.on('auth:changed', (_, { isLoggedIn, userName }) => {
    tray.setContextMenu(buildMenu(isLoggedIn, userName));
  });

  return tray;
}

function showWindow(route = null) {
  if (!mainWindow) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
  if (route) mainWindow.webContents.send('navigate', route);
}

function setupAutoUpdater() {
  autoUpdater.autoDownload         = true;
  autoUpdater.autoInstallOnAppQuit = true;

  autoUpdater.on('checking-for-update', () => mainWindow?.webContents.send('updater:checking'));
  autoUpdater.on('update-available', (info) => {
    mainWindow?.webContents.send('updater:available', info);
    new Notification({ title: 'Aerora Update Available', body: `Version ${info.version} is downloading...` }).show();
  });
  autoUpdater.on('update-not-available', () => mainWindow?.webContents.send('updater:not-available'));
  autoUpdater.on('download-progress', (progress) => {
    mainWindow?.webContents.send('updater:progress', progress);
    mainWindow?.setProgressBar(progress.percent / 100);
  });
  autoUpdater.on('update-downloaded', (info) => {
    mainWindow?.setProgressBar(-1);
    mainWindow?.webContents.send('updater:downloaded', info);
    dialog.showMessageBox(mainWindow, {
      type: 'info', title: 'Update Ready',
      message: `Aerora Dynamics ${info.version} is ready to install.`,
      buttons: ['Restart & Install', 'Later'], defaultId: 0,
    }).then(({ response }) => { if (response === 0) autoUpdater.quitAndInstall(); });
  });
  autoUpdater.on('error', (err) => mainWindow?.webContents.send('updater:error', err.message));

  if (!isDev) {
    autoUpdater.checkForUpdatesAndNotify();
    setInterval(() => autoUpdater.checkForUpdatesAndNotify(), 2 * 60 * 60 * 1000);
  }
}

function setupIPC() {
  ipcMain.on('window:minimize', () => mainWindow?.minimize());
  ipcMain.on('window:maximize', () => mainWindow?.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize());
  ipcMain.on('window:close',    () => mainWindow?.close());
  ipcMain.on('window:isMaximized', (e) => { e.returnValue = mainWindow?.isMaximized() ?? false; });

  ipcMain.handle('store:get',    (_, key)        => store.get(key));
  ipcMain.handle('store:set',    (_, key, value) => store.set(key, value));
  ipcMain.handle('store:delete', (_, key)        => store.delete(key));
  ipcMain.handle('store:getAll', ()              => store.store);

  ipcMain.handle('auth:saveToken', (_, token) => { store.set('authToken', token); return true; });
  ipcMain.handle('auth:getToken',  ()          => store.get('authToken'));
  ipcMain.handle('auth:clearToken',()          => { store.delete('authToken'); store.delete('lastUser'); return true; });

  ipcMain.handle('app:getVersion',  () => app.getVersion());
  ipcMain.handle('app:getApiUrl',   () => store.get('apiUrl', CLOUD_API));
  ipcMain.handle('app:setApiUrl',   (_, url) => store.set('apiUrl', url));
  ipcMain.handle('app:getPlatform', () => process.platform);

  ipcMain.handle('dialog:openFile', async (_, options) => dialog.showOpenDialog(mainWindow, options));
  ipcMain.handle('dialog:saveFile', async (_, options) => dialog.showSaveDialog(mainWindow, options));

  ipcMain.on('notify', (_, { title, body }) => {
    if (store.get('notifications') && Notification.isSupported()) {
      new Notification({ title, body, icon: ICON_PATH }).show();
    }
  });

  ipcMain.on('shell:openExternal', (_, url) => shell.openExternal(url));
  ipcMain.on('updater:checkNow', () => autoUpdater.checkForUpdatesAndNotify());

  ipcMain.handle('theme:get', () => nativeTheme.shouldUseDarkColors ? 'dark' : 'light');
  nativeTheme.on('updated', () => {
    mainWindow?.webContents.send('theme:changed', nativeTheme.shouldUseDarkColors ? 'dark' : 'light');
  });
}

function setupDeepLink() {
  if (process.defaultApp) {
    if (process.argv.length >= 2) app.setAsDefaultProtocolClient('aerora', process.execPath, [process.argv[1]]);
  } else {
    app.setAsDefaultProtocolClient('aerora');
  }

  app.on('second-instance', (_, argv) => {
    if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
    const deepLink = argv.find(arg => arg.startsWith('aerora://'));
    if (deepLink) handleDeepLink(deepLink);
  });
  app.on('open-url', (_, url) => handleDeepLink(url));
}

function handleDeepLink(url) {
  const route = url.replace('aerora://', '/');
  mainWindow?.webContents.send('navigate', route);
  showWindow();
}

app.whenReady().then(() => {
  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'Content-Security-Policy': [
          `default-src 'self' ${CLOUD_API} wss://api.aerora-dynamics.com; ` +
          "script-src 'self' 'unsafe-inline'; " +
          "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
          "font-src 'self' https://fonts.gstatic.com; " +
          "img-src 'self' data: https:;"
        ],
      },
    });
  });

  createMainWindow();
  createTray();
  setupIPC();
  setupDeepLink();
  setupAutoUpdater();
});

app.on('window-all-closed', () => { if (process.platform === 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createMainWindow(); else showWindow(); });
app.on('before-quit', () => { isQuitting = true; });
