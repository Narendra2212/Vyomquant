/**
 * Aerora Dynamics — Windows Desktop App
 * src/renderer/api/client.js — Cloud API Client
 */

import axios from 'axios';

const api = axios.create({
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

export async function initApiClient() {
  const apiUrl = await window.aerora.app.getApiUrl();
  api.defaults.baseURL = apiUrl || 'https://api.aerora-dynamics.com';
}

api.interceptors.request.use(async (config) => {
  const token = await window.aerora.auth.getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await window.aerora.auth.clearToken();
      window.dispatchEvent(new CustomEvent('aerora:unauthorized'));
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  login:   (email, password) => api.post('/api/v1/auth/login', { email, password }),
  logout:  ()                => api.post('/api/v1/auth/logout'),
  me:      ()                => api.get('/api/v1/auth/me'),
  refresh: ()                => api.post('/api/v1/auth/refresh'),
  changePassword: (old_password, new_password) =>
    api.post('/api/v1/auth/change-password', { old_password, new_password }),
};

export const metricsAPI = {
  snapshot:        ()       => api.get('/api/v1/metrics/snapshot'),
  timeSeries:      (metric, days) => api.get(`/api/v1/metrics/timeseries/${metric}`, { params: { days } }),
  pipelineSummary: ()       => api.get('/api/v1/metrics/pipeline'),
  fundosFunnel:    ()       => api.get('/api/v1/metrics/funnel'),
};

export const leadsAPI = {
  getAll:    (params)      => api.get('/api/v1/leads', { params }),
  getById:   (id)          => api.get(`/api/v1/leads/${id}`),
  create:    (data)        => api.post('/api/v1/leads', data),
  update:    (id, data)    => api.patch(`/api/v1/leads/${id}`, data),
  delete:    (id)          => api.delete(`/api/v1/leads/${id}`),
  search:    (q)           => api.get('/api/v1/leads/search', { params: { q } }),
  import:    (formData)    => api.post('/api/v1/leads/import', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  export:    ()            => api.get('/api/v1/leads/export', { responseType: 'blob' }),
  score:     (id)          => api.post(`/api/v1/leads/${id}/score`),
  runScraper:(config)      => api.post('/api/v1/leads/scrape', config),
};

export const crmAPI = {
  getDeals:       (stage)  => api.get('/api/v1/pipeline', { params: { stage } }),
  createDeal:     (data)   => api.post('/api/v1/pipeline', data),
  updateDeal:     (id, d)  => api.patch(`/api/v1/pipeline/${id}`, d),
  moveDeal:       (id, stage) => api.patch(`/api/v1/pipeline/${id}/stage`, { stage }),
  deleteDeal:     (id)     => api.delete(`/api/v1/pipeline/${id}`),
  summary:        ()       => api.get('/api/v1/pipeline/summary'),
};

export const emailAPI = {
  getCampaigns:  ()          => api.get('/api/v1/email/campaigns'),
  getCampaign:   (id)        => api.get(`/api/v1/email/campaigns/${id}`),
  createCampaign:(data)      => api.post('/api/v1/email/campaigns', data),
  launchCampaign:(id, opts)  => api.post(`/api/v1/email/campaigns/${id}/launch`, opts),
  getLogs:       (id)        => api.get(`/api/v1/email/campaigns/${id}/logs`),
  getTemplates:  ()          => api.get('/api/v1/email/templates'),
  testSMTP:      ()          => api.post('/api/v1/email/test-smtp'),
  getInbox:      ()          => api.get('/api/v1/email/inbox'),
};

export const socialAPI = {
  getPosts:    (params)  => api.get('/api/v1/social/posts', { params }),
  createPost:  (data)    => api.post('/api/v1/social/posts', data),
  broadcast:   (data)    => api.post('/api/v1/social/broadcast', data),
  testConn:    ()        => api.get('/api/v1/social/connections'),
  analytics:   ()        => api.get('/api/v1/social/analytics'),
};

export const aiAPI = {
  getContent:       (type)   => api.get('/api/v1/ai/content', { params: { type } }),
  generateTweets:   (data)   => api.post('/api/v1/ai/tweet-thread', data),
  generateLinkedIn: (data)   => api.post('/api/v1/ai/linkedin-post', data),
  generateEmail:    (data)   => api.post('/api/v1/ai/email-copy', data),
  generateScript:   (data)   => api.post('/api/v1/ai/video-script', data),
  generateBlog:     (data)   => api.post('/api/v1/ai/blog-post', data),
  dailyBriefing:    ()       => api.post('/api/v1/ai/daily-briefing'),
  buildVideo:       (data)   => api.post('/api/v1/ai/build-video', data),
};

export const buildAPI = {
  getUnits:      ()          => api.get('/api/v1/build/units'),
  createUnit:    (data)      => api.post('/api/v1/build/units', data),
  updateStatus:  (id, status)=> api.patch(`/api/v1/build/units/${id}`, { status }),
  getLogs:       (unitId)    => api.get('/api/v1/build/logs', { params: { unit_id: unitId } }),
  addLog:        (data)      => api.post('/api/v1/build/logs', data),
  getTests:      (unitId)    => api.get('/api/v1/build/tests', { params: { unit_id: unitId } }),
  addTest:       (data)      => api.post('/api/v1/build/tests', data),
  getBOM:        ()          => api.get('/api/v1/build/bom'),
  addPart:       (data)      => api.post('/api/v1/build/bom', data),
  updateStock:   (pn, qty)   => api.patch(`/api/v1/build/bom/${pn}`, { quantity: qty }),
  getLowStock:   ()          => api.get('/api/v1/build/bom/low-stock'),
  getOrders:     ()          => api.get('/api/v1/build/bom/orders'),
  placeOrder:    (data)      => api.post('/api/v1/build/bom/orders', data),
  getIssues:     (status)    => api.get('/api/v1/build/issues', { params: { status } }),
  createIssue:   (data)      => api.post('/api/v1/build/issues', data),
  updateIssue:   (id, data)  => api.patch(`/api/v1/build/issues/${id}`, data),
  getMilestones: ()          => api.get('/api/v1/build/milestones'),
  createMilestone:(data)     => api.post('/api/v1/build/milestones', data),
  updateMilestone:(id, data) => api.patch(`/api/v1/build/milestones/${id}`, data),
};

export const hrAPI = {
  getTeam:        ()          => api.get('/api/v1/hr/team'),
  updateProfile:  (uid, data) => api.patch(`/api/v1/hr/team/${uid}`, data),
  getLeave:       (params)    => api.get('/api/v1/hr/leave', { params }),
  requestLeave:   (data)      => api.post('/api/v1/hr/leave', data),
  approveLeave:   (id)        => api.patch(`/api/v1/hr/leave/${id}/approve`),
  getOKRs:        (quarter)   => api.get('/api/v1/hr/okrs', { params: { quarter } }),
  createOKR:      (data)      => api.post('/api/v1/hr/okrs', data),
  updateKR:       (id, val)   => api.patch(`/api/v1/hr/okrs/kr/${id}`, { current_value: val }),
  getRoles:       ()          => api.get('/api/v1/hr/recruitment'),
  createRole:     (data)      => api.post('/api/v1/hr/recruitment', data),
  getCandidates:  (roleId)    => api.get(`/api/v1/hr/recruitment/${roleId}/candidates`),
  addCandidate:   (rId, data) => api.post(`/api/v1/hr/recruitment/${rId}/candidates`, data),
  updateCandidate:(id, data)  => api.patch(`/api/v1/hr/candidates/${id}`, data),
};

export const financeAPI = {
  getRunway:       ()          => api.get('/api/v1/finance/runway'),
  getRunwayHistory:()          => api.get('/api/v1/finance/runway/history'),
  addRunwaySnapshot:(data)     => api.post('/api/v1/finance/runway', data),
  getBudget:       (period)    => api.get('/api/v1/finance/budget', { params: { period } }),
  addBudgetItem:   (data)      => api.post('/api/v1/finance/budget', data),
  getExpenses:     (params)    => api.get('/api/v1/finance/expenses', { params }),
  submitExpense:   (data)      => api.post('/api/v1/finance/expenses', data),
  approveExpense:  (id)        => api.patch(`/api/v1/finance/expenses/${id}/approve`),
  getGrants:       ()          => api.get('/api/v1/finance/grants'),
  addGrant:        (data)      => api.post('/api/v1/finance/grants', data),
  updateGrant:     (id, data)  => api.patch(`/api/v1/finance/grants/${id}`, data),
};

export const complianceAPI = {
  getIP:           ()          => api.get('/api/v1/compliance/ip'),
  addIP:           (data)      => api.post('/api/v1/compliance/ip', data),
  updateIP:        (id, data)  => api.patch(`/api/v1/compliance/ip/${id}`, data),
  getNDAs:         ()          => api.get('/api/v1/compliance/ndas'),
  addNDA:          (data)      => api.post('/api/v1/compliance/ndas', data),
  getRegulatory:   ()          => api.get('/api/v1/compliance/regulatory'),
  addRegulatory:   (data)      => api.post('/api/v1/compliance/regulatory', data),
  updateRegulatory:(id, data)  => api.patch(`/api/v1/compliance/regulatory/${id}`, data),
  getExpiring:     (days)      => api.get('/api/v1/compliance/expiring', { params: { days } }),
  getCerts:        ()          => api.get('/api/v1/compliance/certs'),
  addCert:         (data)      => api.post('/api/v1/compliance/certs', data),
};

export const fundraisingAPI = {
  getInvestors:    (params)    => api.get('/api/v1/investors', { params }),
  getInvestor:     (id)        => api.get(`/api/v1/investors/${id}`),
  updateInvestor:  (id, data)  => api.patch(`/api/v1/investors/${id}`, data),
  getCRM:          ()          => api.get('/api/v1/crm'),
  updateCRM:       (id, data)  => api.patch(`/api/v1/crm/${id}`, data),
  getGrants:       ()          => api.get('/api/v1/grants'),
  getFunnel:       ()          => api.get('/api/v1/analytics/funnel'),
  getAnalytics:    ()          => api.get('/api/v1/analytics/summary'),
  getCampaigns:    ()          => api.get('/api/v1/outreach/campaigns'),
  sendOutreach:    (data)      => api.post('/api/v1/outreach/send', data),
  getMilestones:   ()          => api.get('/api/v1/milestones'),
  updateMilestone: (id, data)  => api.patch(`/api/v1/milestones/${id}`, data),
};

export const usersAPI = {
  getAll:          ()          => api.get('/api/v1/users'),
  create:          (data)      => api.post('/api/v1/users', data),
  update:          (id, data)  => api.patch(`/api/v1/users/${id}`, data),
  updateRole:      (id, role)  => api.patch(`/api/v1/users/${id}/role`, { role }),
  deactivate:      (id)        => api.patch(`/api/v1/users/${id}/deactivate`),
  reactivate:      (id)        => api.patch(`/api/v1/users/${id}/reactivate`),
  resetPassword:   (id, pw)    => api.patch(`/api/v1/users/${id}/reset-password`, { password: pw }),
  getAuditLog:     (params)    => api.get('/api/v1/audit-log', { params }),
  getNotifications:()          => api.get('/api/v1/notifications'),
  markRead:        (id)        => api.patch(`/api/v1/notifications/${id}/read`),
};

export const bridgeAPI = {
  getStatus:       ()          => api.get('/api/v1/bridge/status'),
  runSync:         (dryRun)    => api.post('/api/v1/bridge/sync', { dry_run: dryRun }),
  getEvents:       ()          => api.get('/api/v1/bridge/events'),
  getContactMap:   ()          => api.get('/api/v1/bridge/contacts'),
};

export const healthAPI = {
  check: () => api.get('/api/health'),
};

export default api;
