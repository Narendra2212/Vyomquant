import React from 'react';
import {
  LayoutDashboard, TrendingUp, Users, Share2,
  Wrench, DollarSign, UserCheck, Shield, Plug, Settings,
  Bell, User, LogOut, ChevronLeft, ChevronRight,
} from 'lucide-react';
import { useAuthStore, useUIStore } from '../store';

const ROLE_MODULES = {
  super_admin:    ['dashboard','fundraising','sales','marketing','build','finance','hr','compliance','bridge','admin'],
  executive:      ['dashboard','fundraising','sales','marketing','build','finance','hr','compliance'],
  technical_lead: ['dashboard','build','compliance'],
  technical:      ['dashboard','build'],
  biz_dev:        ['dashboard','sales','marketing'],
  marketing:      ['dashboard','marketing'],
  finance_ops:    ['dashboard','finance'],
  hr_admin:       ['dashboard','hr'],
};

const NAV_ITEMS = [
  { id: 'dashboard',   label: 'Dashboard',          icon: LayoutDashboard, route: '/dashboard',   color: '#00d4ff' },
  { id: 'fundraising', label: 'Fundraising',        icon: TrendingUp,      route: '/fundraising', color: '#f59e0b' },
  { id: 'sales',       label: 'Sales & CRM',        icon: Users,           route: '/sales',       color: '#10b981' },
  { id: 'marketing',   label: 'Marketing',          icon: Share2,          route: '/marketing',   color: '#ec4899' },
  { id: 'build',       label: 'Build & Ops',        icon: Wrench,          route: '/build',       color: '#3b82f6' },
  { id: 'finance',     label: 'Finance',            icon: DollarSign,      route: '/finance',     color: '#14b8a6' },
  { id: 'hr',          label: 'Team & HR',          icon: UserCheck,       route: '/hr',          color: '#8b5cf6' },
  { id: 'compliance',  label: 'Compliance & IP',    icon: Shield,          route: '/compliance',  color: '#f97316' },
  { id: 'bridge',      label: 'Integration Bridge', icon: Plug,            route: '/bridge',      color: '#6366f1' },
  { id: 'admin',       label: 'Platform Admin',     icon: Settings,        route: '/admin',       color: '#ef4444' },
];

const BOTTOM_ITEMS = [
  { id: 'notifications', label: 'Notifications', icon: Bell, route: '/notifications' },
  { id: 'profile',       label: 'My Profile',    icon: User, route: '/profile' },
];

export default function Sidebar() {
  const { user, logout } = useAuthStore();
  const { currentRoute, navigate, sidebarCollapsed, toggleSidebar, unreadCount } = useUIStore();
  const allowed = ROLE_MODULES[user?.role] || ['dashboard'];
  const visibleItems = NAV_ITEMS.filter(item => allowed.includes(item.id));
  const isActive = (route) => currentRoute === route;

  return (
    <aside style={{
      width: sidebarCollapsed ? 60 : 220, minWidth: sidebarCollapsed ? 60 : 220,
      background: '#080f1d', borderRight: '1px solid #112240',
      display: 'flex', flexDirection: 'column', transition: 'width 0.2s ease',
      overflow: 'hidden', zIndex: 100,
    }}>
      {!sidebarCollapsed && (
        <div style={{ padding: '16px 14px', borderBottom: '1px solid #112240', display: 'flex', alignItems: 'center', gap: 10 }}>
          <Avatar user={user} />
          <div style={{ overflow: 'hidden' }}>
            <div style={{ color: '#ccd6f6', fontWeight: 700, fontSize: 13, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {user?.full_name || 'Loading…'}
            </div>
            <div style={{ color: roleColor(user?.role), fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>
              {formatRole(user?.role)}
            </div>
          </div>
        </div>
      )}
      {sidebarCollapsed && (
        <div style={{ padding: '14px 0', display: 'flex', justifyContent: 'center', borderBottom: '1px solid #112240' }}>
          <Avatar user={user} size={32} />
        </div>
      )}

      <nav style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        {visibleItems.map(item => (
          <NavItem key={item.id} item={item} active={isActive(item.route)} collapsed={sidebarCollapsed} onClick={() => navigate(item.route)} />
        ))}
      </nav>

      <div style={{ borderTop: '1px solid #112240', padding: '8px 0' }}>
        {BOTTOM_ITEMS.map(item => (
          <NavItem
            key={item.id}
            item={{ ...item, label: item.id === 'notifications' ? `Notifications${unreadCount > 0 ? ` (${unreadCount})` : ''}` : item.label }}
            active={isActive(item.route)} collapsed={sidebarCollapsed} onClick={() => navigate(item.route)}
            badge={item.id === 'notifications' && unreadCount > 0 ? unreadCount : null}
          />
        ))}
        <button onClick={logout} style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 10,
          padding: sidebarCollapsed ? '10px 0' : '10px 14px',
          justifyContent: sidebarCollapsed ? 'center' : 'flex-start',
          background: 'transparent', border: 'none', color: '#ef4444', cursor: 'pointer', fontSize: 13,
        }}>
          <LogOut size={16} />{!sidebarCollapsed && <span>Sign Out</span>}
        </button>
        <button onClick={toggleSidebar} style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 10,
          padding: sidebarCollapsed ? '10px 0' : '10px 14px',
          justifyContent: sidebarCollapsed ? 'center' : 'flex-start',
          background: 'transparent', border: 'none', color: '#4a5568', cursor: 'pointer', fontSize: 13,
          borderTop: '1px solid #112240',
        }}>
          {sidebarCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          {!sidebarCollapsed && <span style={{ fontSize: 11 }}>Collapse</span>}
        </button>
      </div>
    </aside>
  );
}

function NavItem({ item, active, collapsed, onClick, badge }) {
  const Icon = item.icon;
  return (
    <button onClick={onClick} title={collapsed ? item.label : undefined} style={{
      width: '100%', display: 'flex', alignItems: 'center', gap: 10,
      padding: collapsed ? '10px 0' : '10px 14px',
      justifyContent: collapsed ? 'center' : 'flex-start',
      background: active ? `${item.color || '#00d4ff'}18` : 'transparent',
      borderLeft: active ? `3px solid ${item.color || '#00d4ff'}` : '3px solid transparent',
      border: 'none', color: active ? (item.color || '#00d4ff') : '#8892b0',
      cursor: 'pointer', fontSize: 13, fontWeight: active ? 600 : 400,
      transition: 'all 0.15s', position: 'relative',
    }}>
      <Icon size={16} style={{ flexShrink: 0 }} />
      {!collapsed && <span style={{ whiteSpace: 'nowrap' }}>{item.label}</span>}
      {badge && !collapsed && (
        <span style={{ marginLeft: 'auto', background: '#ef4444', color: 'white', borderRadius: 10, fontSize: 10, fontWeight: 700, padding: '1px 6px', minWidth: 18, textAlign: 'center' }}>{badge}</span>
      )}
      {badge && collapsed && (
        <span style={{ position: 'absolute', top: 6, right: 6, background: '#ef4444', color: 'white', borderRadius: '50%', fontSize: 9, fontWeight: 700, width: 14, height: 14, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{badge > 9 ? '9+' : badge}</span>
      )}
    </button>
  );
}

function Avatar({ user, size = 38 }) {
  const initials = user?.full_name ? user.full_name.split(' ').map(p => p[0]).join('').slice(0, 2).toUpperCase() : '??';
  const color = roleColor(user?.role);
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', background: `${color}22`, border: `2px solid ${color}`, color,
      display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: size * 0.35, flexShrink: 0,
    }}>{initials}</div>
  );
}

function roleColor(role) {
  const colors = { super_admin: '#ef4444', executive: '#f59e0b', technical_lead: '#3b82f6', technical: '#6366f1', biz_dev: '#10b981', marketing: '#ec4899', finance_ops: '#14b8a6', hr_admin: '#8b5cf6' };
  return colors[role] || '#6b7280';
}

function formatRole(role) {
  const labels = { super_admin: 'Super Admin', executive: 'Executive', technical_lead: 'Tech Lead', technical: 'Engineer', biz_dev: 'Biz Dev', marketing: 'Marketing', finance_ops: 'Finance', hr_admin: 'HR' };
  return labels[role] || role || '';
}
