import React, { useState, useEffect } from 'react';
import { Minus, X, Maximize2, Minimize2 } from 'lucide-react';
import { useAuthStore } from '../store';

export default function TitleBar() {
  const [isMaximized, setIsMaximized] = useState(false);
  const { user } = useAuthStore();

  useEffect(() => {
    setIsMaximized(window.aerora.window.isMaximized());
    window.aerora.window.onMaximize((v) => setIsMaximized(v));
  }, []);

  const handleMinimize = () => window.aerora.window.minimize();
  const handleMaximize = () => { window.aerora.window.maximize(); setIsMaximized(!isMaximized); };
  const handleClose    = () => window.aerora.window.close();

  return (
    <div style={{
      height: 32, background: '#050e1a', borderBottom: '1px solid #112240',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      WebkitAppRegion: 'drag', userSelect: 'none', flexShrink: 0, zIndex: 9999,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 14px', fontSize: 12 }}>
        <span style={{ fontSize: 14 }}>🚁</span>
        <span style={{ color: '#00d4ff', fontWeight: 700, letterSpacing: 1 }}>AERORA DYNAMICS</span>
        <span style={{ color: '#1e3a5f', margin: '0 4px' }}>|</span>
        <span style={{ color: '#4a5568', fontSize: 11 }}>Command Platform</span>
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', alignItems: 'center', WebkitAppRegion: 'no-drag' }}>
        {user && (
          <span style={{ color: '#8892b0', fontSize: 11, padding: '0 12px', borderRight: '1px solid #1e3a5f' }}>
            {user.full_name}
          </span>
        )}
        <button onClick={handleMinimize} style={btnStyle}><Minus size={10} /></button>
        <button onClick={handleMaximize} style={btnStyle}>{isMaximized ? <Minimize2 size={10} /> : <Maximize2 size={10} />}</button>
        <button onClick={handleClose} style={btnStyle}><X size={10} /></button>
      </div>
    </div>
  );
}

const btnStyle = {
  width: 46, height: 32, border: 'none', background: 'transparent',
  color: '#8892b0', cursor: 'pointer', display: 'flex',
  alignItems: 'center', justifyContent: 'center', outline: 'none',
};
