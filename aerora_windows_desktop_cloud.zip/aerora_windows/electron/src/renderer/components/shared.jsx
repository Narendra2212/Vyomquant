import React from 'react';

export function PageWrapper({ title, subtitle, children, action }) {
  return (
    <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 20, height: '100%', overflowY: 'auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 style={{ color: '#ccd6f6', fontSize: 22, fontWeight: 800, margin: 0 }}>{title}</h1>
          {subtitle && <p style={{ color: '#8892b0', fontSize: 13, margin: '4px 0 0' }}>{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

export function Card({ children, title, style = {} }) {
  return (
    <div style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid #1e3a5f', borderRadius: 12, padding: '18px 20px', ...style }}>
      {title && <div style={{ color: '#00d4ff', fontSize: 13, fontWeight: 700, marginBottom: 14, textTransform: 'uppercase', letterSpacing: 0.5 }}>{title}</div>}
      {children}
    </div>
  );
}

export function Badge({ label, color = '#6b7280' }) {
  return (
    <span style={{ background: `${color}22`, color, border: `1px solid ${color}44`, borderRadius: 10, padding: '2px 10px', fontSize: 11, fontWeight: 600 }}>
      {label}
    </span>
  );
}

export function Button({ children, onClick, variant = 'primary', disabled = false, style = {} }) {
  const variants = {
    primary:   { background: 'linear-gradient(135deg,#00b4d8,#00d4ff)', color: '#0a192f', border: 'none' },
    secondary: { background: 'transparent', color: '#00d4ff', border: '1px solid #00d4ff' },
    danger:    { background: 'transparent', color: '#ef4444', border: '1px solid #ef4444' },
    success:   { background: 'transparent', color: '#10b981', border: '1px solid #10b981' },
  };
  return (
    <button onClick={onClick} disabled={disabled} style={{
      ...(variants[variant] || variants.primary),
      borderRadius: 8, padding: '9px 18px', fontSize: 13,
      fontWeight: 600, cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1, transition: 'all 0.15s', ...style,
    }}>
      {children}
    </button>
  );
}

export function Input({ label, value, onChange, placeholder, type = 'text', style = {} }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {label && <label style={{ color: '#8892b0', fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>{label}</label>}
      <input type={type} value={value} onChange={onChange} placeholder={placeholder} style={{
        background: '#0a192f', border: '1px solid #1e3a5f', borderRadius: 8,
        padding: '9px 12px', color: '#ccd6f6', fontSize: 13, outline: 'none',
        width: '100%', boxSizing: 'border-box', ...style,
      }} />
    </div>
  );
}

export function Table({ columns, data, onRowClick }) {
  if (!data?.length) return <div style={{ color: '#4a5568', fontSize: 13, padding: 20, textAlign: 'center' }}>No records found.</div>;
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
        <thead>
          <tr>
            {columns.map(col => (
              <th key={col.key} style={{ color: '#8892b0', fontWeight: 600, textAlign: 'left', padding: '8px 12px', borderBottom: '1px solid #1e3a5f', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr key={i} onClick={() => onRowClick?.(row)} style={{ borderBottom: '1px solid #0a192f', cursor: onRowClick ? 'pointer' : 'default' }}>
              {columns.map(col => (
                <td key={col.key} style={{ padding: '10px 12px', color: '#ccd6f6' }}>
                  {col.render ? col.render(row[col.key], row) : (row[col.key] ?? '—')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function StatRow({ stats }) {
  return (
    <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
      {stats.map(({ label, value, color = '#00d4ff' }, i) => (
        <div key={i} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid #1e3a5f', borderRadius: 10, padding: '14px 18px', flex: 1, minWidth: 120 }}>
          <div style={{ fontSize: 22, fontWeight: 700, color }}>{value ?? '—'}</div>
          <div style={{ fontSize: 11, color: '#8892b0', textTransform: 'uppercase', letterSpacing: 1, marginTop: 4 }}>{label}</div>
        </div>
      ))}
    </div>
  );
}
