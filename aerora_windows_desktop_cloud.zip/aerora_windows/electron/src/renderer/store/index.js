/**
 * Aerora Dynamics — Windows Desktop App
 * src/renderer/store/index.js — Global State (Zustand)
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { authAPI, metricsAPI } from '../api/client';

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null, token: null, isLoading: false, error: null,

      login: async (email, password) => {
        set({ isLoading: true, error: null });
        try {
          const { data } = await authAPI.login(email, password);
          const token = data.access_token;
          await window.aerora.auth.saveToken(token);
          window.aerora.auth.notifyChange({ isLoggedIn: true, userName: data.user?.full_name });
          set({ token, user: data.user, isLoading: false });
          return { success: true };
        } catch (err) {
          const msg = err.response?.data?.detail || 'Login failed. Check your credentials.';
          set({ error: msg, isLoading: false });
          return { success: false, error: msg };
        }
      },

      logout: async () => {
        try { await authAPI.logout(); } catch (_) {}
        await window.aerora.auth.clearToken();
        window.aerora.auth.notifyChange({ isLoggedIn: false });
        set({ user: null, token: null, error: null });
      },

      loadUser: async () => {
        const token = await window.aerora.auth.getToken();
        if (!token) return;
        try {
          const { data } = await authAPI.me();
          set({ user: data, token });
          window.aerora.auth.notifyChange({ isLoggedIn: true, userName: data.full_name });
        } catch (_) {
          await window.aerora.auth.clearToken();
          set({ user: null, token: null });
        }
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: 'aerora-auth',
      storage: createJSONStorage(() => sessionStorage),
      partialize: (s) => ({ user: s.user }),
    }
  )
);

export const useMetricsStore = create((set) => ({
  snapshot: null, funnel: null, pipeline: null,
  isLoading: false, lastFetched: null,

  fetchAll: async () => {
    set({ isLoading: true });
    try {
      const [snap, funnel, pipeline] = await Promise.allSettled([
        metricsAPI.snapshot(), metricsAPI.fundosFunnel(), metricsAPI.pipelineSummary(),
      ]);
      set({
        snapshot:    snap.status     === 'fulfilled' ? snap.value.data     : null,
        funnel:      funnel.status   === 'fulfilled' ? funnel.value.data   : null,
        pipeline:    pipeline.status === 'fulfilled' ? pipeline.value.data : null,
        isLoading:   false, lastFetched: new Date().toISOString(),
      });
    } catch (_) { set({ isLoading: false }); }
  },
}));

export const useUIStore = create((set, get) => ({
  currentRoute: '/dashboard', sidebarCollapsed: false,
  notifications: [], unreadCount: 0, alerts: [],

  navigate: (route) => set({ currentRoute: route }),
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setNotifications: (n) => set({ notifications: n, unreadCount: n.filter(x => !x.is_read).length }),
  markRead: (id) => set((s) => ({
    notifications: s.notifications.map(n => n.id === id ? { ...n, is_read: true } : n),
    unreadCount: Math.max(0, s.unreadCount - 1),
  })),
  addAlert:    (alert) => set((s) => ({ alerts: [...s.alerts, { id: Date.now(), ...alert }] })),
  removeAlert: (id)    => set((s) => ({ alerts: s.alerts.filter(a => a.id !== id) })),
}));

export const useSettingsStore = create((set, get) => ({
  apiUrl: '', theme: 'dark', notifications: true, startMinimized: false,

  load: async () => {
    const all = await window.aerora.store.getAll();
    set({
      apiUrl:         all.apiUrl         || 'https://api.aerora-dynamics.com',
      theme:          all.theme          || 'dark',
      notifications:  all.notifications  ?? true,
      startMinimized: all.startMinimized ?? false,
    });
  },

  save: async (key, value) => {
    await window.aerora.store.set(key, value);
    set({ [key]: value });
  },
}));
