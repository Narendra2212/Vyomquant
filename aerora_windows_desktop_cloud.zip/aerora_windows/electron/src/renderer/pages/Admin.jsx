export { Admin as default } from './AllPages.jsx';
