export { Compliance as default } from './AllPages.jsx';
