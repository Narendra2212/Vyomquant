export { Profile as default } from './AllPages.jsx';
