import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, Wifi, WifiOff } from 'lucide-react';
import { useAuthStore, useSettingsStore } from '../store';
import { healthAPI } from '../api/client';

export default function Login() {
  const [email, setEmail]     = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [apiOnline, setApiOnline] = useState(null);
  const [version, setVersion] = useState('');

  const { login, isLoading, error, clearError } = useAuthStore();
  const { apiUrl } = useSettingsStore();

  useEffect(() => {
    window.aerora.app.getVersion().then(setVersion);
    checkApiHealth();
    const interval = setInterval(checkApiHealth, 15000);
    return () => clearInterval(interval);
  }, [apiUrl]);

  async function checkApiHealth() {
    try { await healthAPI.check(); setApiOnline(true); }
    catch { setApiOnline(false); }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!email || !password) return;
    clearError();
    const result = await login(email, password);
    if (result.success) window.aerora.notify('Welcome Back', 'Signed in to Aerora Dynamics');
  }

  return (
    <div style={styles.page}>
      <div style={styles.grid} />
      <div style={styles.card}>
        <div style={styles.logoBlock}>
          <div style={styles.logoIcon}>🚁</div>
          <div style={styles.logoName}>AERORA DYNAMICS</div>
          <div style={styles.logoSub}>COMMAND PLATFORM</div>
          <div style={styles.version}>v{version}</div>
        </div>

        <div style={styles.apiStatus}>
          {apiOnline === null ? <span style={{ color: '#4a5568' }}>Checking connection…</span>
            : apiOnline ? <span style={{ color: '#10b981', display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'center' }}><Wifi size={12} /> Connected to cloud</span>
            : <span style={{ color: '#ef4444', display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'center' }}><WifiOff size={12} /> Cloud offline — check settings</span>}
        </div>

        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.field}>
            <label style={styles.label}>Email Address</label>
            <input type="email" value={email} onChange={e => { setEmail(e.target.value); clearError(); }}
              placeholder="you@aerora-dynamics.com" autoComplete="email" autoFocus style={styles.input} />
          </div>
          <div style={styles.field}>
            <label style={styles.label}>Password</label>
            <div style={{ position: 'relative' }}>
              <input type={showPass ? 'text' : 'password'} value={password}
                onChange={e => { setPassword(e.target.value); clearError(); }}
                placeholder="••••••••••" autoComplete="current-password" style={{ ...styles.input, paddingRight: 42 }} />
              <button type="button" onClick={() => setShowPass(!showPass)} style={styles.eyeBtn}>
                {showPass ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>
          {error && <div style={styles.errorBox}>{error}</div>}
          <button type="submit" disabled={isLoading || !email || !password} style={{
            ...styles.submitBtn, opacity: (isLoading || !email || !password) ? 0.6 : 1,
            cursor: (isLoading || !email || !password) ? 'not-allowed' : 'pointer',
          }}>{isLoading ? 'Signing in…' : 'Sign In'}</button>
        </form>

        <div style={styles.footer}>
          <span style={{ color: '#4a5568' }}>First time? Contact your administrator for access.</span><br />
          <span style={{ color: '#4a5568', fontSize: 11 }}>Default: admin@aerora-dynamics.com</span>
        </div>
      </div>
      <div style={styles.bottomStrip}>
        <span>Aerora Dynamics Ltd</span><span>·</span>
        <span style={{ cursor: 'pointer', textDecoration: 'underline' }} onClick={() => window.aerora.openExternal('https://aerora-dynamics.com/privacy')}>Privacy Policy</span>
      </div>
    </div>
  );
}

const styles = {
  page: { height: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(160deg, #050e1a 0%, #0a192f 100%)', position: 'relative', overflow: 'hidden' },
  grid: { position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(0,212,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,255,0.04) 1px, transparent 1px)', backgroundSize: '40px 40px', pointerEvents: 'none' },
  card: { width: 400, background: 'rgba(255,255,255,0.04)', border: '1px solid #1e3a5f', borderRadius: 16, padding: '40px 36px', zIndex: 1, boxShadow: '0 25px 50px rgba(0,0,0,0.5)' },
  logoBlock: { textAlign: 'center', marginBottom: 24 },
  logoIcon: { fontSize: 48, lineHeight: 1, marginBottom: 12 },
  logoName: { color: '#00d4ff', fontSize: 20, fontWeight: 800, letterSpacing: 2 },
  logoSub: { color: '#8892b0', fontSize: 11, letterSpacing: 3, marginTop: 4 },
  version: { color: '#1e3a5f', fontSize: 10, marginTop: 4 },
  apiStatus: { textAlign: 'center', fontSize: 12, marginBottom: 24, height: 20 },
  form: { display: 'flex', flexDirection: 'column', gap: 16 },
  field: { display: 'flex', flexDirection: 'column', gap: 6 },
  label: { color: '#8892b0', fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { background: '#0a192f', border: '1px solid #1e3a5f', borderRadius: 8, padding: '11px 14px', color: '#ccd6f6', fontSize: 14, outline: 'none', width: '100%', boxSizing: 'border-box' },
  eyeBtn: { position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'transparent', border: 'none', color: '#4a5568', cursor: 'pointer' },
  errorBox: { background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 8, padding: '10px 14px', color: '#fca5a5', fontSize: 13 },
  submitBtn: { background: 'linear-gradient(135deg, #00b4d8, #00d4ff)', border: 'none', borderRadius: 8, padding: '13px', color: '#0a192f', fontSize: 15, fontWeight: 700, cursor: 'pointer', marginTop: 4 },
  footer: { textAlign: 'center', marginTop: 20, fontSize: 12, lineHeight: 1.7 },
  bottomStrip: { position: 'fixed', bottom: 0, left: 0, right: 0, display: 'flex', gap: 10, justifyContent: 'center', padding: '8px', color: '#1e3a5f', fontSize: 11, zIndex: 2 },
};
