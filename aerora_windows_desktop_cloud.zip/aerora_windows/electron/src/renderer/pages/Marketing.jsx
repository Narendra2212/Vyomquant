export { Marketing as default } from './AllPages.jsx';
