export { HR as default } from './AllPages.jsx';
