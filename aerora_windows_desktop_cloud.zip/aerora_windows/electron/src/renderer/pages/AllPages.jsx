import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { PageWrapper, Card, Button, Table, Input, Badge, StatRow } from '../components/shared';
import { Search, Download } from 'lucide-react';
import { useAuthStore, useUIStore, useSettingsStore } from '../store';
import api, { leadsAPI, crmAPI, emailAPI } from '../api/client';

/* ───────────────────────── SALES ───────────────────────── */
export function Sales() {
  const [tab, setTab] = useState('crm');
  const [search, setSearch] = useState('');
  const qc = useQueryClient();

  const { data: leads }   = useQuery({ queryKey: ['leads', search], queryFn: () => leadsAPI.getAll({ q: search }).then(r => r.data?.leads || []) });
  const { data: deals }   = useQuery({ queryKey: ['pipeline'], queryFn: () => crmAPI.getDeals().then(r => r.data?.deals || []) });
  const { data: campaigns } = useQuery({ queryKey: ['campaigns'], queryFn: () => emailAPI.getCampaigns().then(r => r.data || []) });

  const moveDeal = useMutation({
    mutationFn: ({ id, stage }) => crmAPI.moveDeal(id, stage),
    onSuccess: () => { qc.invalidateQueries(['pipeline']); toast.success('Deal moved'); },
  });

  const STAGES = ['Discovered','Contacted','Demo Scheduled','Proposal Sent','Negotiation','Closed Won','Closed Lost'];
  const STAGE_COLORS = { 'Discovered':'#6B7280','Contacted':'#3B82F6','Demo Scheduled':'#F59E0B','Proposal Sent':'#8B5CF6','Negotiation':'#F97316','Closed Won':'#10B981','Closed Lost':'#EF4444' };
  const pipelineValue = deals?.filter(d => d.stage !== 'Closed Lost').reduce((s, d) => s + (d.deal_value || 0), 0) || 0;
  const hotLeads = leads?.filter(l => l.score >= 70).length || 0;

  return (
    <PageWrapper title="📡 Sales & CRM" subtitle="Lead management, pipeline, and email campaigns">
      <StatRow stats={[
        { label: 'Total Leads', value: leads?.length || 0, color: '#00d4ff' },
        { label: 'Hot Leads', value: hotLeads, color: '#ef4444' },
        { label: 'Pipeline Value', value: `£${pipelineValue.toLocaleString()}`, color: '#10b981' },
        { label: 'Deals Active', value: deals?.filter(d => !['Closed Won','Closed Lost'].includes(d.stage)).length || 0, color: '#f59e0b' },
      ]} />
      <div style={{ display: 'flex', gap: 4, borderBottom: '1px solid #1e3a5f' }}>
        {['crm','leads','email'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={tabStyle(tab===t,'#00d4ff')}>
            {t === 'crm' ? 'CRM Pipeline' : t === 'leads' ? 'Lead Database' : 'Email Campaigns'}
          </button>
        ))}
      </div>

      {tab === 'crm' && (
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 8 }}>
          {STAGES.map(stage => {
            const stageDeals = deals?.filter(d => d.stage === stage) || [];
            const color = STAGE_COLORS[stage];
            return (
              <div key={stage} style={{ minWidth: 200, maxWidth: 200, background: 'rgba(255,255,255,0.03)', border: '1px solid #1e3a5f', borderRadius: 10, padding: 12 }}>
                <div style={{ borderTop: `3px solid ${color}`, paddingTop: 8, marginBottom: 10 }}>
                  <div style={{ color, fontSize: 11, fontWeight: 700, textTransform: 'uppercase' }}>{stage}</div>
                  <div style={{ color: '#8892b0', fontSize: 11 }}>{stageDeals.length} deals · £{stageDeals.reduce((s,d)=>s+(d.deal_value||0),0).toLocaleString()}</div>
                </div>
                {stageDeals.map(deal => (
                  <div key={deal.id} style={{ background: '#0a192f', borderLeft: `3px solid ${color}`, borderRadius: 6, padding: '8px 10px', marginBottom: 8, fontSize: 12 }}>
                    <div style={{ color: '#ccd6f6', fontWeight: 600 }}>{deal.company_name}</div>
                    <div style={{ color: '#00d4ff', fontWeight: 700, marginTop: 4 }}>£{(deal.deal_value||0).toLocaleString()}</div>
                    <div style={{ color: '#4a5568', fontSize: 11, marginTop: 2 }}>{deal.probability}% probability</div>
                    <select onChange={e => moveDeal.mutate({ id: deal.id, stage: e.target.value })} defaultValue={deal.stage} style={{ marginTop: 6, background: '#112240', border: '1px solid #1e3a5f', color: '#8892b0', borderRadius: 4, padding: '2px 4px', fontSize: 11, width: '100%' }}>
                      {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      )}

      {tab === 'leads' && (
        <Card>
          <div style={{ display: 'flex', gap: 10, marginBottom: 14, flexWrap: 'wrap' }}>
            <div style={{ flex: 1, position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#4a5568' }} />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search leads…" style={{ background: '#0a192f', border: '1px solid #1e3a5f', borderRadius: 8, padding: '8px 12px 8px 32px', color: '#ccd6f6', fontSize: 13, width: '100%', boxSizing: 'border-box', outline: 'none' }} />
            </div>
            <Button variant="secondary" onClick={() => leadsAPI.export().then(r => { const url = URL.createObjectURL(r.data); const a = document.createElement('a'); a.href = url; a.download = 'leads.csv'; a.click(); })}>
              <Download size={13} style={{ marginRight: 6 }} /> Export CSV
            </Button>
          </div>
          <Table columns={[
            { key: 'company_name', label: 'Company' }, { key: 'contact_name', label: 'Contact' },
            { key: 'industry', label: 'Industry' }, { key: 'email', label: 'Email' },
            { key: 'score', label: 'Score', render: v => <Badge label={v} color={v>=70?'#10b981':v>=45?'#f59e0b':'#6b7280'} /> },
            { key: 'status', label: 'Status', render: v => <Badge label={v} /> },
          ]} data={leads} />
        </Card>
      )}

      {tab === 'email' && (
        <Card>
          <Table columns={[
            { key: 'name', label: 'Campaign' },
            { key: 'status', label: 'Status', render: v => <Badge label={v} color={v==='sent'?'#10b981':v==='sending'?'#f59e0b':'#6b7280'} /> },
            { key: 'sent_count', label: 'Sent' }, { key: 'open_count', label: 'Opens' }, { key: 'click_count', label: 'Clicks' },
            { key: 'created_at', label: 'Created', render: v => v?.slice(0,10) },
          ]} data={campaigns} />
        </Card>
      )}
    </PageWrapper>
  );
}

/* ───────────────────────── FUNDRAISING ───────────────────────── */
export function Fundraising() {
  const [tab, setTab] = useState('investors');
  const { data: investors } = useQuery({ queryKey: ['investors'], queryFn: () => api.get('/api/v1/investors').then(r => r.data?.items || []) });
  const { data: funnel }    = useQuery({ queryKey: ['funnel'], queryFn: () => api.get('/api/v1/analytics/funnel').then(r => r.data) });
  const { data: grants }    = useQuery({ queryKey: ['f-grants'], queryFn: () => api.get('/api/v1/grants').then(r => r.data?.items || []) });
  const { data: campaigns } = useQuery({ queryKey: ['f-campaigns'], queryFn: () => api.get('/api/v1/outreach/campaigns').then(r => r.data?.items || []) });

  return (
    <PageWrapper title="💰 Fundraising Hub" subtitle="Investor pipeline powered by FundOS">
      <StatRow stats={[
        { label: 'Discovered', value: funnel?.total_discovered || '—', color: '#6b7280' },
        { label: 'Contacted',  value: funnel?.total_contacted  || '—', color: '#3b82f6' },
        { label: 'Meetings',   value: funnel?.total_meetings   || '—', color: '#f59e0b' },
        { label: 'Term Sheets',value: funnel?.total_term_sheets|| '—', color: '#10b981' },
      ]} />
      <div style={{ display: 'flex', gap: 4, borderBottom: '1px solid #1e3a5f' }}>
        {['investors','grants','outreach'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={tabStyle(tab===t,'#f59e0b')}>{t.charAt(0).toUpperCase()+t.slice(1)}</button>
        ))}
      </div>
      {tab === 'investors' && (
        <Card><Table columns={[
          { key: 'name', label: 'Name' }, { key: 'firm_name', label: 'Firm' }, { key: 'investor_type', label: 'Type' },
          { key: 'location_country', label: 'Country' },
          { key: 'relevance_score', label: 'Relevance', render: v => <Badge label={(v||0).toFixed(0)} color={v>=70?'#10b981':v>=45?'#f59e0b':'#6b7280'} /> },
          { key: 'status', label: 'Status', render: v => <Badge label={v||'new'} /> },
        ]} data={investors} /></Card>
      )}
      {tab === 'grants' && (
        <Card><Table columns={[
          { key: 'title', label: 'Grant', render: v => v?.slice(0,50) }, { key: 'organization', label: 'Funder' }, { key: 'grant_type', label: 'Type' },
          { key: 'funding_amount_max', label: 'Max Amount', render: v => v ? `£${Number(v).toLocaleString()}` : '—' },
          { key: 'deadline', label: 'Deadline', render: v => v?.slice(0,10) },
          { key: 'application_status', label: 'Status', render: v => <Badge label={v||'—'} color={v==='applied'?'#f59e0b':v==='awarded'?'#10b981':'#6b7280'} /> },
        ]} data={grants} /></Card>
      )}
      {tab === 'outreach' && (
        <Card><Table columns={[
          { key: 'name', label: 'Campaign' }, { key: 'status', label: 'Status', render: v => <Badge label={v||'—'} /> },
          { key: 'sent_count', label: 'Sent' },
          { key: 'open_rate', label: 'Open Rate', render: v => v ? `${(v*100).toFixed(1)}%` : '—' },
          { key: 'reply_rate', label: 'Reply Rate', render: v => v ? `${(v*100).toFixed(1)}%` : '—' },
        ]} data={campaigns} /></Card>
      )}
    </PageWrapper>
  );
}

/* ───────────────────────── BUILD OPS ───────────────────────── */
export function BuildOps() {
  const [tab, setTab] = useState('units');
  const { data: units } = useQuery({ queryKey: ['build-units'], queryFn: () => api.get('/api/v1/build/units').then(r => r.data || []) });
  const { data: issues } = useQuery({ queryKey: ['issues'], queryFn: () => api.get('/api/v1/build/issues').then(r => r.data || []) });
  const { data: bom } = useQuery({ queryKey: ['bom'], queryFn: () => api.get('/api/v1/build/bom').then(r => r.data || []) });
  const { data: lowStock } = useQuery({ queryKey: ['low-stock'], queryFn: () => api.get('/api/v1/build/bom/low-stock').then(r => r.data || []) });
  const { data: milestones } = useQuery({ queryKey: ['milestones'], queryFn: () => api.get('/api/v1/build/milestones').then(r => r.data || []) });

  const STATUS_COLOR = { 'In Build':'#3B82F6','Testing':'#F59E0B','QC Hold':'#EF4444','Ready':'#10B981','Deployed':'#8B5CF6','Retired':'#6B7280' };
  const SEV_COLOR = { critical:'#ef4444', high:'#f97316', medium:'#f59e0b', low:'#10b981' };
  const MS_COLOR = { planned:'#6B7280', in_progress:'#F59E0B', completed:'#10B981', delayed:'#EF4444' };

  return (
    <PageWrapper title="🔧 Build & Operations" subtitle="Drone units, test flights, components, and issues">
      <StatRow stats={[
        { label: 'Drone Units', value: units?.length || 0, color: '#3b82f6' },
        { label: 'Open Issues', value: issues?.filter(i=>i.status==='open').length || 0, color: '#ef4444' },
        { label: 'Low Stock Parts', value: lowStock?.length || 0, color: '#f59e0b' },
        { label: 'Milestones Done', value: milestones?.filter(m=>m.status==='completed').length || 0, color: '#10b981' },
      ]} />
      {lowStock?.length > 0 && (
        <div style={{ background:'rgba(239,68,68,0.08)', border:'1px solid rgba(239,68,68,0.3)', borderRadius:8, padding:'10px 16px', color:'#fca5a5', fontSize:13 }}>
          ⚠️ {lowStock.length} parts at or below minimum stock level
        </div>
      )}
      <div style={{ display:'flex', gap:4, borderBottom:'1px solid #1e3a5f' }}>
        {['units','issues','bom','milestones'].map(t => <button key={t} onClick={()=>setTab(t)} style={tabStyle(tab===t,'#3b82f6')}>{t.charAt(0).toUpperCase()+t.slice(1).replace('bom','BOM')}</button>)}
      </div>
      {tab==='units' && (
        <div style={{ display:'flex', gap:14, flexWrap:'wrap' }}>
          {units?.map(u => (
            <div key={u.id} style={{ background:'rgba(255,255,255,0.04)', border:'1px solid #1e3a5f', borderTop:`3px solid ${STATUS_COLOR[u.status]||'#6b7280'}`, borderRadius:10, padding:16, minWidth:180 }}>
              <div style={{ fontSize:24, marginBottom:8 }}>🚁</div>
              <div style={{ color:'#ccd6f6', fontWeight:700 }}>{u.unit_id}</div>
              <div style={{ color:'#8892b0', fontSize:12 }}>{u.model_name}</div>
              <Badge label={u.status} color={STATUS_COLOR[u.status]} />
              <div style={{ color:'#4a5568', fontSize:11, marginTop:6 }}>📍 {u.location||'—'}</div>
            </div>
          ))}
        </div>
      )}
      {tab==='issues' && <Card><Table columns={[
        { key:'id', label:'#' }, { key:'severity', label:'Severity', render:v=><Badge label={v} color={SEV_COLOR[v]} /> },
        { key:'title', label:'Title' }, { key:'unit_id', label:'Unit' }, { key:'category', label:'Category' },
        { key:'status', label:'Status', render:v=><Badge label={v} color={v==='resolved'?'#10b981':v==='open'?'#ef4444':'#f59e0b'} /> },
      ]} data={issues} /></Card>}
      {tab==='bom' && <Card><Table columns={[
        { key:'part_number', label:'P/N' }, { key:'name', label:'Name' }, { key:'category', label:'Category' },
        { key:'unit_cost_gbp', label:'Unit Cost', render:v=>`£${(v||0).toFixed(2)}` },
        { key:'quantity_stock', label:'In Stock' }, { key:'quantity_min', label:'Min Stock' }, { key:'supplier', label:'Supplier' },
      ]} data={bom} /></Card>}
      {tab==='milestones' && (
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {milestones?.map(m => (
            <div key={m.id} style={{ background:'rgba(255,255,255,0.03)', border:'1px solid #1e3a5f', borderLeft:`4px solid ${MS_COLOR[m.status]||'#6b7280'}`, borderRadius:8, padding:'12px 16px' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <div style={{ color:'#ccd6f6', fontWeight:600 }}>{m.title}</div>
                <Badge label={m.status.replace('_',' ')} color={MS_COLOR[m.status]} />
              </div>
              <div style={{ color:'#8892b0', fontSize:12, marginTop:4 }}>📂 {m.category} &nbsp;·&nbsp; 🗓 {m.target_date||'TBD'}</div>
            </div>
          ))}
        </div>
      )}
    </PageWrapper>
  );
}

/* ───────────────────────── FINANCE ───────────────────────── */
export function Finance() {
  const [tab, setTab] = useState('runway');
  const { data: runway } = useQuery({ queryKey:['runway'], queryFn:()=>api.get('/api/v1/finance/runway').then(r=>r.data) });
  const { data: expenses } = useQuery({ queryKey:['expenses'], queryFn:()=>api.get('/api/v1/finance/expenses').then(r=>r.data||[]) });
  const { data: grants } = useQuery({ queryKey:['grants'], queryFn:()=>api.get('/api/v1/finance/grants').then(r=>r.data||[]) });
  const { data: budget } = useQuery({ queryKey:['budget'], queryFn:()=>api.get('/api/v1/finance/budget').then(r=>r.data||[]) });
  const runwayColor = !runway?'#6b7280':runway.runway_months>=12?'#10b981':runway.runway_months>=6?'#f59e0b':'#ef4444';

  return (
    <PageWrapper title="📊 Finance & Budget" subtitle="Cash runway, expenses, budget, and grants">
      <StatRow stats={[
        { label:'Cash Balance', value:runway?`£${runway.cash_balance_gbp?.toLocaleString('en-GB',{maximumFractionDigits:0})}`:'—', color:'#00d4ff' },
        { label:'Monthly Burn', value:runway?`£${runway.monthly_burn_gbp?.toLocaleString('en-GB',{maximumFractionDigits:0})}`:'—', color:'#f59e0b' },
        { label:'Runway', value:runway?`${runway.runway_months?.toFixed(1)} months`:'—', color:runwayColor },
        { label:'Grants Active', value:grants?.filter(g=>g.status==='active').length||0, color:'#8b5cf6' },
      ]} />
      <div style={{ display:'flex', gap:4, borderBottom:'1px solid #1e3a5f' }}>
        {['runway','expenses','budget','grants'].map(t=><button key={t} onClick={()=>setTab(t)} style={tabStyle(tab===t,'#14b8a6')}>{t.charAt(0).toUpperCase()+t.slice(1)}</button>)}
      </div>
      {tab==='runway' && runway && (
        <Card title="Cash Runway">
          <div style={{ display:'flex', gap:20, marginBottom:20 }}>
            {[['Cash', `£${runway.cash_balance_gbp?.toLocaleString()}`, '#00d4ff'],['Burn/mo', `£${runway.monthly_burn_gbp?.toLocaleString()}`, '#f59e0b'],['Runway', `${runway.runway_months?.toFixed(1)}mo`, runwayColor],['Target Raise', `£${(runway.next_fundraise_target_gbp||0).toLocaleString()}`, '#8b5cf6']].map(([l,v,c],i)=>(
              <div key={i} style={{ flex:1, background:'#0a192f', borderRadius:8, padding:14, borderTop:`3px solid ${c}` }}>
                <div style={{ color:c, fontSize:22, fontWeight:700 }}>{v}</div>
                <div style={{ color:'#8892b0', fontSize:11, marginTop:4 }}>{l}</div>
              </div>
            ))}
          </div>
          {runway.runway_months < 9 && <div style={{ background:'rgba(239,68,68,0.1)', border:'1px solid rgba(239,68,68,0.3)', borderRadius:8, padding:'12px 16px', color:'#fca5a5', fontSize:13 }}>🚨 Less than 9 months runway. Begin fundraising immediately.</div>}
        </Card>
      )}
      {tab==='expenses' && <Card><Table columns={[
        { key:'expense_date', label:'Date', render:v=>v?.slice(0,10) }, { key:'description', label:'Description', render:v=>v?.slice(0,45) },
        { key:'category', label:'Category' }, { key:'amount_gbp', label:'Amount', render:v=>`£${(v||0).toFixed(2)}` },
        { key:'submitter', label:'Submitted By' }, { key:'status', label:'Status', render:v=><Badge label={v} color={v==='approved'?'#10b981':v==='pending'?'#f59e0b':'#ef4444'} /> },
      ]} data={expenses} /></Card>}
      {tab==='budget' && <Card><Table columns={[
        { key:'category', label:'Category' }, { key:'description', label:'Description', render:v=>v?.slice(0,40) },
        { key:'amount_gbp', label:'Amount', render:v=>`£${Number(v).toLocaleString()}` }, { key:'period', label:'Period' },
        { key:'budget_type', label:'Type', render:v=><Badge label={v?.toUpperCase()} /> },
      ]} data={budget} /></Card>}
      {tab==='grants' && <Card><Table columns={[
        { key:'title', label:'Grant', render:v=>v?.slice(0,50) }, { key:'funder', label:'Funder' },
        { key:'amount_gbp', label:'Amount', render:v=>v?`£${Number(v).toLocaleString()}`:'—' }, { key:'deadline', label:'Deadline', render:v=>v?.slice(0,10) },
        { key:'status', label:'Status', render:v=><Badge label={v} color={v==='awarded'?'#10b981':v==='submitted'?'#f59e0b':v==='active'?'#8b5cf6':'#6b7280'} /> },
      ]} data={grants} /></Card>}
    </PageWrapper>
  );
}

/* ───────────────────────── HR ───────────────────────── */
export function HR() {
  const [tab, setTab] = useState('team');
  const { data: team } = useQuery({ queryKey:['team'], queryFn:()=>api.get('/api/v1/hr/team').then(r=>r.data||[]) });
  const { data: leave } = useQuery({ queryKey:['leave'], queryFn:()=>api.get('/api/v1/hr/leave').then(r=>r.data||[]) });
  const { data: okrs } = useQuery({ queryKey:['okrs'], queryFn:()=>api.get('/api/v1/hr/okrs').then(r=>r.data||[]) });
  const { data: recruitment } = useQuery({ queryKey:['recruitment'], queryFn:()=>api.get('/api/v1/hr/recruitment').then(r=>r.data||[]) });
  const ROLE_COLORS = { super_admin:'#ef4444',executive:'#f59e0b',technical_lead:'#3b82f6',technical:'#6366f1',biz_dev:'#10b981',marketing:'#ec4899',finance_ops:'#14b8a6',hr_admin:'#8b5cf6' };

  return (
    <PageWrapper title="👥 Team & HR" subtitle="Directory, leave, OKRs, and recruitment">
      <div style={{ display:'flex', gap:4, borderBottom:'1px solid #1e3a5f' }}>
        {['team','leave','okrs','recruitment'].map(t=><button key={t} onClick={()=>setTab(t)} style={tabStyle(tab===t,'#8b5cf6')}>{t.charAt(0).toUpperCase()+t.slice(1)}</button>)}
      </div>
      {tab==='team' && (
        <div style={{ display:'flex', flexWrap:'wrap', gap:14 }}>
          {team?.map(m => {
            const initials = m.full_name?.split(' ').map(p=>p[0]).join('').slice(0,2).toUpperCase();
            const color = ROLE_COLORS[m.role]||'#6b7280';
            return (
              <div key={m.id} style={{ background:'rgba(255,255,255,0.04)', border:'1px solid #1e3a5f', borderRadius:12, padding:16, minWidth:200, maxWidth:240 }}>
                <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
                  <div style={{ width:44, height:44, borderRadius:'50%', background:`${color}22`, border:`2px solid ${color}`, color, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800, fontSize:16 }}>{initials}</div>
                  <div><div style={{ color:'#ccd6f6', fontWeight:700, fontSize:14 }}>{m.full_name}</div><div style={{ color, fontSize:11, fontWeight:600 }}>{m.job_title||m.role}</div></div>
                </div>
                <div style={{ color:'#8892b0', fontSize:12 }}>{m.department}</div>
                <div style={{ color:'#4a5568', fontSize:11, marginTop:4 }}>📧 {m.email}</div>
              </div>
            );
          })}
        </div>
      )}
      {tab==='leave' && <Card><Table columns={[
        { key:'employee_name', label:'Employee' }, { key:'leave_type', label:'Type', render:v=>v?.replace('_',' ') },
        { key:'start_date', label:'From' }, { key:'end_date', label:'To' }, { key:'days_count', label:'Days' },
        { key:'status', label:'Status', render:v=><Badge label={v} color={v==='approved'?'#10b981':v==='pending'?'#f59e0b':'#ef4444'} /> },
      ]} data={leave} /></Card>}
      {tab==='okrs' && (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          {okrs?.map(okr => (
            <Card key={okr.id}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                <div style={{ color:'#ccd6f6', fontWeight:700, fontSize:15 }}>{okr.objective}</div>
                <div style={{ color:'#00d4ff', fontSize:13, fontWeight:600 }}>{okr.overall_progress?.toFixed(0)}%</div>
              </div>
              <div style={{ background:'#1e3a5f', borderRadius:6, height:6, marginBottom:14 }}><div style={{ background:'#00d4ff', width:`${Math.min(100,okr.overall_progress||0)}%`, height:6, borderRadius:6 }} /></div>
              {okr.key_results?.map(kr => (
                <div key={kr.id} style={{ display:'flex', alignItems:'center', gap:12, marginBottom:8 }}>
                  <div style={{ flex:1, color:'#8892b0', fontSize:13 }}>{kr.description}</div>
                  <div style={{ color:'#ccd6f6', fontSize:12, whiteSpace:'nowrap' }}>{kr.current_value} / {kr.target_value} {kr.unit}</div>
                  <div style={{ width:80, background:'#1e3a5f', borderRadius:4, height:4 }}><div style={{ background:'#10b981', width:`${Math.min(100,(kr.current_value/kr.target_value)*100||0)}%`, height:4, borderRadius:4 }} /></div>
                </div>
              ))}
            </Card>
          ))}
        </div>
      )}
      {tab==='recruitment' && <Card><Table columns={[
        { key:'role_title', label:'Role' }, { key:'department', label:'Department' }, { key:'seniority', label:'Seniority' },
        { key:'salary_min_gbp', label:'Salary Min', render:v=>v?`£${Number(v).toLocaleString()}`:'—' },
        { key:'salary_max_gbp', label:'Salary Max', render:v=>v?`£${Number(v).toLocaleString()}`:'—' },
        { key:'candidate_count', label:'Candidates' },
        { key:'status', label:'Status', render:v=><Badge label={v} color={v==='open'?'#10b981':v==='filled'?'#6b7280':'#f59e0b'} /> },
      ]} data={recruitment} /></Card>}
    </PageWrapper>
  );
}

/* ───────────────────────── COMPLIANCE ───────────────────────── */
export function Compliance() {
  const [tab, setTab] = useState('regulatory');
  const { data: ip } = useQuery({ queryKey:['ip'], queryFn:()=>api.get('/api/v1/compliance/ip').then(r=>r.data||[]) });
  const { data: ndas } = useQuery({ queryKey:['ndas'], queryFn:()=>api.get('/api/v1/compliance/ndas').then(r=>r.data||[]) });
  const { data: regulatory } = useQuery({ queryKey:['regulatory'], queryFn:()=>api.get('/api/v1/compliance/regulatory').then(r=>r.data||[]) });
  const { data: certs } = useQuery({ queryKey:['certs'], queryFn:()=>api.get('/api/v1/compliance/certs').then(r=>r.data||[]) });
  const { data: expiring } = useQuery({ queryKey:['expiring'], queryFn:()=>api.get('/api/v1/compliance/expiring',{params:{days:60}}).then(r=>r.data||[]) });

  return (
    <PageWrapper title="⚖️ Compliance & IP" subtitle="Patents, NDAs, regulatory approvals, and certifications">
      {expiring?.length > 0 && <div style={{ background:'rgba(239,68,68,0.08)', border:'1px solid rgba(239,68,68,0.3)', borderRadius:8, padding:'10px 16px', color:'#fca5a5', fontSize:13 }}>⚠️ {expiring.length} regulatory item(s) expiring within 60 days</div>}
      <div style={{ display:'flex', gap:4, borderBottom:'1px solid #1e3a5f' }}>
        {['regulatory','ip','ndas','certs'].map(t=><button key={t} onClick={()=>setTab(t)} style={tabStyle(tab===t,'#f97316')}>{t==='ip'?'IP Log':t==='ndas'?'NDAs':t==='certs'?'Certifications':'Regulatory'}</button>)}
      </div>
      {tab==='regulatory' && <Card><Table columns={[
        { key:'title', label:'Title', render:v=>v?.slice(0,45) }, { key:'reg_type', label:'Type' }, { key:'jurisdiction', label:'Jurisdiction' },
        { key:'expiry_date', label:'Expiry', render:v=>v?.slice(0,10) },
        { key:'status', label:'Status', render:v=><Badge label={v?.replace('_',' ')} color={v==='approved'?'#10b981':v==='expired'?'#ef4444':'#f59e0b'} /> },
      ]} data={regulatory} /></Card>}
      {tab==='ip' && <Card><Table columns={[
        { key:'title', label:'Title', render:v=>v?.slice(0,45) }, { key:'ip_type', label:'Type' }, { key:'jurisdiction', label:'Jurisdiction' },
        { key:'reference_number', label:'Reference' }, { key:'filing_date', label:'Filed', render:v=>v?.slice(0,10) },
        { key:'status', label:'Status', render:v=><Badge label={v} color={v==='granted'?'#10b981':v==='filed'?'#3b82f6':v==='provisional'?'#f59e0b':'#6b7280'} /> },
      ]} data={ip} /></Card>}
      {tab==='ndas' && <Card><Table columns={[
        { key:'counterparty', label:'Counterparty' }, { key:'nda_type', label:'Type', render:v=>v?.replace('_',' ') },
        { key:'purpose', label:'Purpose', render:v=>v?.slice(0,40) }, { key:'signed_date', label:'Signed', render:v=>v?.slice(0,10) },
        { key:'expiry_date', label:'Expires', render:v=>v?.slice(0,10) }, { key:'status', label:'Status', render:v=><Badge label={v} color={v==='active'?'#10b981':'#6b7280'} /> },
      ]} data={ndas} /></Card>}
      {tab==='certs' && <Card><Table columns={[
        { key:'title', label:'Certification', render:v=>v?.slice(0,45) }, { key:'cert_type', label:'Type' }, { key:'standard', label:'Standard' },
        { key:'issued_to', label:'Issued To' }, { key:'expiry_date', label:'Expiry', render:v=>v?.slice(0,10) },
        { key:'status', label:'Status', render:v=><Badge label={v} color={v==='certified'?'#10b981':'#6b7280'} /> },
      ]} data={certs} /></Card>}
    </PageWrapper>
  );
}

/* ───────────────────────── MARKETING ───────────────────────── */
export function Marketing() {
  const [tab, setTab] = useState('social');
  const { data: posts } = useQuery({ queryKey:['posts'], queryFn:()=>api.get('/api/v1/social/posts').then(r=>r.data||[]) });
  const { data: campaigns } = useQuery({ queryKey:['mkt-camp'], queryFn:()=>api.get('/api/v1/email/campaigns').then(r=>r.data||[]) });
  const { data: aiContent } = useQuery({ queryKey:['ai-content'], queryFn:()=>api.get('/api/v1/ai/content').then(r=>r.data||[]) });

  return (
    <PageWrapper title="📣 Marketing" subtitle="Social hub, email campaigns, and AI content">
      <div style={{ display:'flex', gap:4, borderBottom:'1px solid #1e3a5f' }}>
        {['social','email','ai'].map(t=><button key={t} onClick={()=>setTab(t)} style={tabStyle(tab===t,'#ec4899')}>{t==='social'?'Social Hub':t==='email'?'Email Campaigns':'AI Content'}</button>)}
      </div>
      {tab==='social' && <Card><Table columns={[
        { key:'platform', label:'Platform', render:v=><Badge label={v} color={v==='twitter'?'#1DA1F2':v==='linkedin'?'#0A66C2':'#E1306C'} /> },
        { key:'content', label:'Content', render:v=>v?.slice(0,60) },
        { key:'status', label:'Status', render:v=><Badge label={v} color={v==='posted'?'#10b981':v==='scheduled'?'#f59e0b':'#6b7280'} /> },
        { key:'scheduled_at', label:'Scheduled', render:v=>v?.slice(0,16) }, { key:'posted_at', label:'Posted', render:v=>v?.slice(0,16) },
      ]} data={posts} /></Card>}
      {tab==='email' && <Card><Table columns={[
        { key:'name', label:'Campaign' }, { key:'status', label:'Status', render:v=><Badge label={v} color={v==='sent'?'#10b981':v==='sending'?'#f59e0b':'#6b7280'} /> },
        { key:'sent_count', label:'Sent' }, { key:'open_count', label:'Opens' }, { key:'click_count', label:'Clicks' },
        { key:'created_at', label:'Created', render:v=>v?.slice(0,10) },
      ]} data={campaigns} /></Card>}
      {tab==='ai' && <Card><Table columns={[
        { key:'content_type', label:'Type', render:v=>v?.replace('_',' ') }, { key:'title', label:'Title', render:v=>v?.slice(0,50) },
        { key:'platform', label:'Platform' }, { key:'status', label:'Status', render:v=><Badge label={v} /> },
        { key:'created_at', label:'Created', render:v=>v?.slice(0,10) },
      ]} data={aiContent} /></Card>}
    </PageWrapper>
  );
}

/* ───────────────────────── BRIDGE ───────────────────────── */
export function Bridge() {
  const { data: status } = useQuery({ queryKey:['bridge-st'], queryFn:()=>api.get('/api/v1/bridge/status').then(r=>r.data) });
  const { data: events } = useQuery({ queryKey:['bridge-ev'], queryFn:()=>api.get('/api/v1/bridge/events').then(r=>r.data||[]) });
  const [syncing, setSyncing] = useState(false);
  const [dryRun, setDryRun] = useState(true);

  async function runSync() {
    setSyncing(true);
    try {
      const { data } = await api.post('/api/v1/bridge/sync', { dry_run: dryRun });
      toast.success(`Sync complete: ${Object.values(data).reduce((s,r)=>s+(r.records_affected||0),0)} records`);
    } catch { toast.error('Sync failed'); }
    setSyncing(false);
  }

  return (
    <PageWrapper title="🔌 Integration Bridge" subtitle="FundOS ↔ Sales & Marketing sync control">
      <div style={{ display:'flex', gap:14 }}>
        {[['FundOS API',status?.fundos_api],['Sales DB',status?.sales_db],['Bridge DB',status?.bridge_db],['AI Service',status?.ai_ok]].map(([label,ok])=>(
          <div key={label} style={{ flex:1, background:'rgba(255,255,255,0.04)', border:'1px solid #1e3a5f', borderRadius:10, padding:14 }}>
            <div style={{ color:ok?'#10b981':'#ef4444', fontSize:22 }}>{ok?'●':'○'}</div>
            <div style={{ color:'#ccd6f6', fontWeight:600, marginTop:4 }}>{label}</div>
            <div style={{ color:ok?'#10b981':'#ef4444', fontSize:12 }}>{ok?'Online':'Offline'}</div>
          </div>
        ))}
      </div>
      <Card title="Manual Sync">
        <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:14 }}>
          <label style={{ display:'flex', alignItems:'center', gap:8, color:'#8892b0', fontSize:13, cursor:'pointer' }}>
            <input type="checkbox" checked={dryRun} onChange={e=>setDryRun(e.target.checked)} /> Dry run (no writes)
          </label>
          <Button onClick={runSync} disabled={syncing}>{syncing?'Running…':'▶ Run Full Sync'}</Button>
        </div>
        <Table columns={[{key:'created_at',label:'Time',render:v=>v?.slice(0,16)},{key:'event_type',label:'Event'},{key:'source_app',label:'Source'},{key:'target_app',label:'Target'},{key:'status',label:'Status',render:v=><Badge label={v} color={v==='success'?'#10b981':'#ef4444'} />}]} data={events?.slice(0,30)} />
      </Card>
    </PageWrapper>
  );
}

/* ───────────────────────── ADMIN ───────────────────────── */
export function Admin() {
  const { data: users } = useQuery({ queryKey:['users'], queryFn:()=>api.get('/api/v1/users').then(r=>r.data||[]) });
  const { data: auditLog } = useQuery({ queryKey:['audit-log'], queryFn:()=>api.get('/api/v1/audit-log').then(r=>r.data||[]) });
  const [tab, setTab] = useState('users');
  const ROLE_LABELS = { super_admin:'Super Admin', executive:'Executive', technical_lead:'Tech Lead', technical:'Engineer', biz_dev:'Biz Dev', marketing:'Marketing', finance_ops:'Finance', hr_admin:'HR' };
  const ROLE_COLORS = { super_admin:'#ef4444', executive:'#f59e0b', technical_lead:'#3b82f6', technical:'#6366f1', biz_dev:'#10b981', marketing:'#ec4899', finance_ops:'#14b8a6', hr_admin:'#8b5cf6' };
  return (
    <PageWrapper title="⚙️ Platform Admin" subtitle="User management, roles, and audit log">
      <div style={{ display:'flex', gap:4, borderBottom:'1px solid #1e3a5f' }}>
        {['users','audit'].map(t=><button key={t} onClick={()=>setTab(t)} style={tabStyle(tab===t,'#ef4444')}>{t==='users'?'Users':'Audit Log'}</button>)}
      </div>
      {tab==='users' && <Card><Table columns={[
        { key:'id', label:'ID' }, { key:'full_name', label:'Name' }, { key:'email', label:'Email' },
        { key:'role', label:'Role', render:v=><Badge label={ROLE_LABELS[v]||v} color={ROLE_COLORS[v]||'#6b7280'} /> },
        { key:'department', label:'Dept' }, { key:'is_active', label:'Active', render:v=><Badge label={v?'Active':'Inactive'} color={v?'#10b981':'#ef4444'} /> },
        { key:'last_login', label:'Last Login', render:v=>v?.slice(0,10)||'Never' },
      ]} data={users} /></Card>}
      {tab==='audit' && <Card><Table columns={[
        { key:'created_at', label:'Time', render:v=>v?.slice(0,16) }, { key:'user_email', label:'User' }, { key:'action', label:'Action' },
        { key:'module', label:'Module' }, { key:'detail', label:'Detail', render:v=>v?.slice(0,50) },
        { key:'status', label:'Status', render:v=><Badge label={v} color={v==='success'?'#10b981':'#ef4444'} /> },
      ]} data={auditLog?.slice(0,100)} /></Card>}
    </PageWrapper>
  );
}

/* ───────────────────────── PROFILE ───────────────────────── */
export function Profile() {
  const { user, logout } = useAuthStore();
  const [oldPw, setOldPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const ROLE_COLORS = { super_admin:'#ef4444', executive:'#f59e0b', technical_lead:'#3b82f6', technical:'#6366f1', biz_dev:'#10b981', marketing:'#ec4899', finance_ops:'#14b8a6', hr_admin:'#8b5cf6' };
  const color = ROLE_COLORS[user?.role] || '#6b7280';
  const initials = user?.full_name?.split(' ').map(p=>p[0]).join('').slice(0,2).toUpperCase();

  async function changePw() {
    try {
      await api.post('/api/v1/auth/change-password', { old_password: oldPw, new_password: newPw });
      toast.success('Password changed. Please sign in again.');
      setTimeout(() => logout(), 1500);
    } catch (e) { toast.error(e.response?.data?.detail || 'Failed'); }
  }

  return (
    <PageWrapper title="👤 My Profile" subtitle="Personal details and security">
      <div style={{ display:'flex', gap:20, flexWrap:'wrap' }}>
        <Card style={{ flex:'0 0 280px' }}>
          <div style={{ textAlign:'center' }}>
            <div style={{ width:80, height:80, borderRadius:'50%', background:`${color}22`, border:`3px solid ${color}`, color, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800, fontSize:24, margin:'0 auto 14px' }}>{initials}</div>
            <div style={{ color:'#ccd6f6', fontWeight:700, fontSize:18 }}>{user?.full_name}</div>
            <div style={{ color, fontSize:12, fontWeight:600, marginTop:4 }}>{user?.role?.replace('_',' ').toUpperCase()}</div>
            <div style={{ color:'#8892b0', fontSize:12, marginTop:6 }}>{user?.email}</div>
            <div style={{ color:'#4a5568', fontSize:11, marginTop:4 }}>Last login: {user?.last_login?.slice(0,16)||'First session'}</div>
          </div>
        </Card>
        <Card title="Change Password" style={{ flex:1 }}>
          <div style={{ display:'flex', flexDirection:'column', gap:14, maxWidth:360 }}>
            <Input label="Current Password" type="password" value={oldPw} onChange={e=>setOldPw(e.target.value)} />
            <Input label="New Password" type="password" value={newPw} onChange={e=>setNewPw(e.target.value)} placeholder="Min 10 chars, upper, number, special" />
            <Button onClick={changePw} disabled={!oldPw||!newPw}>Update Password</Button>
          </div>
        </Card>
      </div>
    </PageWrapper>
  );
}

/* ───────────────────────── NOTIFICATIONS ───────────────────────── */
export function Notifications() {
  const { data: notifs, refetch } = useQuery({ queryKey:['notifs'], queryFn:()=>api.get('/api/v1/notifications').then(r=>r.data||[]) });
  async function markRead(id) { await api.patch(`/api/v1/notifications/${id}/read`); refetch(); useUIStore.getState().markRead(id); }
  return (
    <PageWrapper title="🔔 Notifications" subtitle="Platform alerts and messages">
      {notifs?.filter(n=>!n.is_read).length === 0 ? (
        <Card><div style={{ color:'#10b981', textAlign:'center', padding:20 }}>✅ All caught up — no unread notifications.</div></Card>
      ) : (
        notifs?.filter(n=>!n.is_read).map(n=>(
          <div key={n.id} style={{ background:'rgba(255,255,255,0.04)', border:'1px solid #1e3a5f', borderLeft:'3px solid #00d4ff', borderRadius:8, padding:'14px 16px', display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
            <div>
              <div style={{ color:'#ccd6f6', fontWeight:600 }}>{n.title}</div>
              <div style={{ color:'#8892b0', fontSize:13, marginTop:4 }}>{n.body}</div>
              <div style={{ color:'#4a5568', fontSize:11, marginTop:4 }}>{n.created_at?.slice(0,16)}</div>
            </div>
            <Button variant="secondary" onClick={()=>markRead(n.id)} style={{ fontSize:11, padding:'4px 10px' }}>Mark read</Button>
          </div>
        ))
      )}
    </PageWrapper>
  );
}

/* ───────────────────────── APP SETTINGS ───────────────────────── */
export function AppSettings() {
  const { apiUrl, save } = useSettingsStore();
  const [localApiUrl, setLocalApiUrl] = useState(apiUrl);
  const [version, setVersion] = useState('');
  useEffect(() => { window.aerora.app.getVersion().then(setVersion); }, []);
  return (
    <PageWrapper title="⚙️ App Settings" subtitle="Configure cloud API and application preferences">
      <Card title="Cloud API Connection">
        <div style={{ display:'flex', flexDirection:'column', gap:14, maxWidth:480 }}>
          <Input label="Cloud API URL" value={localApiUrl} onChange={e=>setLocalApiUrl(e.target.value)} placeholder="https://api.aerora-dynamics.com" />
          <Button onClick={()=>{ save('apiUrl', localApiUrl); toast.success('API URL saved. Restart the app.'); }}>Save API URL</Button>
        </div>
      </Card>
      <Card title="About">
        <div style={{ color:'#8892b0', fontSize:13, display:'flex', flexDirection:'column', gap:8 }}>
          <div>Version: <span style={{ color:'#ccd6f6' }}>v{version}</span></div>
          <div>Platform: <span style={{ color:'#ccd6f6' }}>Windows Desktop (Electron)</span></div>
          <div>Backend: <span style={{ color:'#ccd6f6' }}>{localApiUrl}</span></div>
          <div style={{ marginTop:8, display:'flex', gap:10 }}>
            <Button variant="secondary" onClick={()=>window.aerora.updater.checkNow()} style={{ fontSize:12 }}>Check for Updates</Button>
            <Button variant="secondary" onClick={()=>window.aerora.openExternal('https://aerora-dynamics.com/docs')} style={{ fontSize:12 }}>Documentation</Button>
          </div>
        </div>
      </Card>
    </PageWrapper>
  );
}

/* ───────────────────────── shared helpers ───────────────────────── */
function tabStyle(active, color) {
  return {
    background: active ? `${color}1a` : 'transparent', border: 'none',
    borderBottom: active ? `2px solid ${color}` : '2px solid transparent',
    color: active ? color : '#8892b0', padding: '8px 18px', cursor: 'pointer',
    fontSize: 13, fontWeight: 600,
  };
}
