import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, LabelList } from 'recharts';
import { Users, DollarSign, TrendingUp, Zap, AlertTriangle, CheckCircle, Activity, RefreshCw } from 'lucide-react';
import { metricsAPI, buildAPI, financeAPI, complianceAPI, bridgeAPI } from '../api/client';
import { useUIStore } from '../store';

const STAGE_COLORS = { 'Discovered': '#6B7280', 'Contacted': '#3B82F6', 'Demo Scheduled': '#F59E0B', 'Proposal Sent': '#8B5CF6', 'Negotiation': '#F97316', 'Closed Won': '#10B981', 'Closed Lost': '#EF4444' };

export default function Dashboard() {
  const { navigate } = useUIStore();
  const [refreshKey, setRefreshKey] = useState(0);

  const { data: snap, isLoading: loadSnap } = useQuery({ queryKey: ['snapshot', refreshKey], queryFn: () => metricsAPI.snapshot().then(r => r.data), staleTime: 60000 });
  const { data: funnel } = useQuery({ queryKey: ['funnel', refreshKey], queryFn: () => metricsAPI.fundosFunnel().then(r => r.data), staleTime: 60000 });
  const { data: pipeline } = useQuery({ queryKey: ['pipeline', refreshKey], queryFn: () => metricsAPI.pipelineSummary().then(r => r.data), staleTime: 60000 });
  const { data: runway } = useQuery({ queryKey: ['runway'], queryFn: () => financeAPI.getRunway().then(r => r.data), staleTime: 300000 });
  const { data: issues } = useQuery({ queryKey: ['issues-open'], queryFn: () => buildAPI.getIssues('open').then(r => r.data), staleTime: 120000 });
  const { data: expiring } = useQuery({ queryKey: ['expiring'], queryFn: () => complianceAPI.getExpiring(60).then(r => r.data), staleTime: 300000 });
  const { data: bridgeStatus } = useQuery({ queryKey: ['bridge-status'], queryFn: () => bridgeAPI.getStatus().then(r => r.data), staleTime: 30000 });

  const isLoading = loadSnap;

  const pipelineData = pipeline ? Object.entries(pipeline).map(([stage, d]) => ({ stage, deals: d.count || 0, value: d.total_value || 0 })) : [];
  const runwayColor = !runway ? '#6b7280' : runway.runway_months >= 12 ? '#10b981' : runway.runway_months >= 6 ? '#f59e0b' : '#ef4444';

  const alerts = [
    ...(issues?.filter(i=>i.severity==='critical').length > 0 ? [{ msg: `${issues.filter(i=>i.severity==='critical').length} critical open issues` }] : []),
    ...(runway && runway.runway_months < 9 ? [{ msg: `Only ${runway.runway_months?.toFixed(1)} months runway` }] : []),
    ...(expiring?.length > 0 ? [{ msg: `${expiring.length} regulatory items expiring in 60 days` }] : []),
  ];

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Command Dashboard</h1>
          <p style={styles.subtitle}>{new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
        </div>
        <button onClick={() => setRefreshKey(k => k + 1)} style={styles.refreshBtn}><RefreshCw size={14} style={{ marginRight: 6 }} />Refresh</button>
      </div>

      <div style={styles.kpiRow}>
        {[
          { label: 'Pipeline Value', value: `£${(snap?.pipeline_value || 0).toLocaleString('en-GB',{maximumFractionDigits:0})}`, icon: DollarSign, color: '#00d4ff', sub: 'B2B sales' },
          { label: 'Total Leads',    value: (snap?.total_leads || 0).toLocaleString(), icon: Users, color: '#10b981', sub: 'scraped & imported' },
          { label: 'Investors Found',value: funnel?.total_discovered || '—', icon: TrendingUp, color: '#f59e0b', sub: 'FundOS' },
          { label: 'Cash Runway',    value: runway ? `${runway.runway_months?.toFixed(1)}mo` : '—', icon: Activity, color: runwayColor, sub: runway ? `£${(runway.cash_balance_gbp||0).toLocaleString('en-GB',{maximumFractionDigits:0})} cash` : '' },
          { label: 'Open Issues',    value: issues?.length || 0, icon: Zap, color: issues?.filter(i=>i.severity==='critical').length > 0 ? '#ef4444' : '#6b7280', sub: 'build & ops' },
          { label: 'Emails Today',   value: snap?.emails_sent_today || 0, icon: CheckCircle, color: '#8b5cf6', sub: 'sales outreach' },
        ].map((kpi, i) => <KPICard key={i} {...kpi} loading={isLoading} />)}
      </div>

      {alerts.length > 0 && (
        <div style={styles.alertBanner}>
          <AlertTriangle size={14} style={{ color: '#ef4444', marginRight: 8, flexShrink: 0 }} />
          <span style={{ color: '#fca5a5', fontSize: 13 }}>{alerts.map(a => a.msg).join('  ·  ')}</span>
        </div>
      )}

      <div style={styles.chartRow}>
        <div style={styles.card}>
          <h3 style={styles.cardTitle}>B2B Sales Pipeline</h3>
          {pipelineData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={pipelineData} barSize={28}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f" />
                <XAxis dataKey="stage" stroke="#4a5568" tick={{ fontSize: 9 }} />
                <YAxis stroke="#4a5568" tick={{ fontSize: 11 }} tickFormatter={v => `£${(v/1000).toFixed(0)}k`} />
                <Tooltip contentStyle={{ background: '#0a192f', border: '1px solid #1e3a5f', borderRadius: 8, color: '#ccd6f6' }} formatter={(v) => [`£${v.toLocaleString()}`, 'Value']} />
                <Bar dataKey="value" radius={[4,4,0,0]}>
                  {pipelineData.map((entry, i) => <Cell key={i} fill={STAGE_COLORS[entry.stage] || '#00d4ff'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState msg="No pipeline data yet" />}
        </div>

        <div style={styles.card}>
          <h3 style={styles.cardTitle}>System Status</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: '8px 0' }}>
            {[
              { label: 'Cloud API',      ok: bridgeStatus?.api_online ?? false },
              { label: 'FundOS Backend', ok: bridgeStatus?.fundos_api ?? false },
              { label: 'Sales Database', ok: bridgeStatus?.sales_db ?? false },
              { label: 'Bridge Sync',    ok: bridgeStatus?.bridge_running ?? false },
            ].map(({ label, ok }) => (
              <div key={label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 12px', background: '#0a192f', borderRadius: 6 }}>
                <span style={{ color: '#ccd6f6', fontSize: 13 }}>{label}</span>
                <span style={{ color: ok ? '#10b981' : '#ef4444', fontSize: 12, fontWeight: 600 }}>{ok ? '● Online' : '● Offline'}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={styles.card}>
        <h3 style={styles.cardTitle}>Quick Actions</h3>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          {[
            { label: '➕ Add Lead', route: '/sales', color: '#10b981' },
            { label: '📧 New Campaign', route: '/marketing', color: '#8b5cf6' },
            { label: '💰 Investor Outreach', route: '/fundraising', color: '#f59e0b' },
            { label: '🔧 Log Build Entry', route: '/build', color: '#3b82f6' },
            { label: '🧾 Submit Expense', route: '/finance', color: '#14b8a6' },
            { label: '🏖️ Request Leave', route: '/hr', color: '#ec4899' },
          ].map(({ label, route, color }) => (
            <button key={route} onClick={() => navigate(route)} style={{ background: `${color}18`, border: `1px solid ${color}44`, color, borderRadius: 8, padding: '10px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>{label}</button>
          ))}
        </div>
      </div>
    </div>
  );
}

function KPICard({ label, value, icon: Icon, color, sub, loading }) {
  return (
    <div style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid #1e3a5f', borderRadius: 12, padding: '18px 20px', flex: 1, minWidth: 140 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontSize: 11, color: '#8892b0', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 }}>{label}</div>
          <div style={{ fontSize: 28, fontWeight: 700, color, lineHeight: 1.1 }}>{loading ? '…' : value}</div>
          {sub && <div style={{ fontSize: 11, color: '#4a5568', marginTop: 4 }}>{sub}</div>}
        </div>
        <Icon size={20} style={{ color: `${color}66` }} />
      </div>
    </div>
  );
}

function EmptyState({ msg }) {
  return <div style={{ height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#4a5568', fontSize: 13 }}>{msg}</div>;
}

const styles = {
  page: { padding: 24, display: 'flex', flexDirection: 'column', gap: 20, overflowY: 'auto', height: '100%', background: 'linear-gradient(160deg, #050e1a 0%, #0a192f 100%)' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' },
  title: { color: '#ccd6f6', fontSize: 22, fontWeight: 800, margin: 0 },
  subtitle: { color: '#8892b0', fontSize: 13, margin: '4px 0 0' },
  refreshBtn: { display: 'flex', alignItems: 'center', background: 'rgba(255,255,255,0.04)', border: '1px solid #1e3a5f', color: '#8892b0', borderRadius: 8, padding: '8px 14px', fontSize: 13, cursor: 'pointer' },
  kpiRow: { display: 'flex', gap: 14, flexWrap: 'wrap' },
  alertBanner: { background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 8, padding: '10px 16px', display: 'flex', alignItems: 'center' },
  chartRow: { display: 'flex', gap: 16 },
  card: { background: 'rgba(255,255,255,0.04)', border: '1px solid #1e3a5f', borderRadius: 12, padding: '18px 20px', flex: 1 },
  cardTitle: { color: '#00d4ff', fontSize: 13, fontWeight: 700, margin: '0 0 14px', textTransform: 'uppercase', letterSpacing: 0.5 },
};
