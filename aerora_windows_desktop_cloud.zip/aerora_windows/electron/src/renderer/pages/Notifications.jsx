export { Notifications as default } from './AllPages.jsx';
