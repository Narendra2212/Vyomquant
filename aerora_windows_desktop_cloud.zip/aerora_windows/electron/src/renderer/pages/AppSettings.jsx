export { AppSettings as default } from './AllPages.jsx';
