export { Finance as default } from './AllPages.jsx';
