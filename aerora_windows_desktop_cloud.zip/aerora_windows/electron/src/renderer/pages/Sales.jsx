export { Sales as default } from './AllPages.jsx';
