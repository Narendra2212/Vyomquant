import React, { useEffect, Suspense, lazy } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import TitleBar from './components/TitleBar';
import Sidebar  from './components/Sidebar';
import { useAuthStore, useUIStore, useSettingsStore } from './store';
import { initApiClient } from './api/client';

const Login         = lazy(() => import('./pages/Login'));
const Dashboard      = lazy(() => import('./pages/Dashboard'));
const Sales          = lazy(() => import('./pages/Sales'));
const Fundraising    = lazy(() => import('./pages/Fundraising'));
const Marketing      = lazy(() => import('./pages/Marketing'));
const BuildOps       = lazy(() => import('./pages/BuildOps'));
const Finance        = lazy(() => import('./pages/Finance'));
const HR             = lazy(() => import('./pages/HR'));
const Compliance     = lazy(() => import('./pages/Compliance'));
const Bridge         = lazy(() => import('./pages/Bridge'));
const Admin          = lazy(() => import('./pages/Admin'));
const Profile        = lazy(() => import('./pages/Profile'));
const Notifications  = lazy(() => import('./pages/Notifications'));
const AppSettings    = lazy(() => import('./pages/AppSettings'));

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 2, retryDelay: 1000, staleTime: 60000, refetchOnWindowFocus: false } },
});

const ROUTES = {
  '/dashboard': Dashboard, '/sales': Sales, '/fundraising': Fundraising,
  '/marketing': Marketing, '/build': BuildOps, '/finance': Finance,
  '/hr': HR, '/compliance': Compliance, '/bridge': Bridge, '/admin': Admin,
  '/profile': Profile, '/notifications': Notifications, '/settings': AppSettings,
};

export default function App() {
  const { user, loadUser } = useAuthStore();
  const { currentRoute, navigate } = useUIStore();
  const { load: loadSettings } = useSettingsStore();

  useEffect(() => {
    (async () => { await loadSettings(); await initApiClient(); await loadUser(); })();
  }, []);

  useEffect(() => { window.aerora.onNavigate((route) => navigate(route)); }, []);

  useEffect(() => {
    const handler = () => useAuthStore.getState().logout();
    window.addEventListener('aerora:unauthorized', handler);
    return () => window.removeEventListener('aerora:unauthorized', handler);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <div style={styles.root}>
        <TitleBar />
        {!user ? (
          <Suspense fallback={<LoadingScreen />}><Login /></Suspense>
        ) : (
          <div style={styles.appBody}>
            <Sidebar />
            <main style={styles.main}>
              <Suspense fallback={<PageLoader />}>
                <PageRenderer route={currentRoute} />
              </Suspense>
            </main>
          </div>
        )}
        <Toaster position="bottom-right" toastOptions={{
          style: { background: '#0a192f', color: '#ccd6f6', border: '1px solid #1e3a5f', borderRadius: 10 },
          success: { iconTheme: { primary: '#10b981', secondary: '#0a192f' } },
          error:   { iconTheme: { primary: '#ef4444', secondary: '#0a192f' } },
        }} />
      </div>
    </QueryClientProvider>
  );
}

function PageRenderer({ route }) {
  const Page = ROUTES[route] || Dashboard;
  return <Page />;
}

function LoadingScreen() {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#050e1a' }}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>🚁</div>
      <div style={{ color: '#00d4ff', fontWeight: 700, letterSpacing: 2, fontSize: 14 }}>AERORA DYNAMICS</div>
      <div style={{ color: '#4a5568', fontSize: 12, marginTop: 8 }}>Loading…</div>
    </div>
  );
}

function PageLoader() {
  return <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#4a5568', fontSize: 13 }}>Loading module…</div>;
}

const styles = {
  root: { width: '100vw', height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden', background: '#050e1a', color: '#ccd6f6', fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif" },
  appBody: { flex: 1, display: 'flex', overflow: 'hidden' },
  main: { flex: 1, overflow: 'auto', background: 'linear-gradient(160deg, #050e1a 0%, #0a192f 100%)' },
};
