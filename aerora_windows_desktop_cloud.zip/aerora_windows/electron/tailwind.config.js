/** Aerora Dynamics — Tailwind config */
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/index.html", "./src/renderer/**/*.{js,jsx,ts,tsx}"],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        aerora: {
          bg: '#050e1a', bgAlt: '#0a192f', border: '#1e3a5f',
          text: '#ccd6f6', muted: '#8892b0', faint: '#4a5568',
          accent: '#00d4ff', success: '#10b981', warning: '#f59e0b',
          danger: '#ef4444', purple: '#8b5cf6',
        },
      },
      fontFamily: { sans: ['Inter', 'Segoe UI', 'system-ui', 'sans-serif'] },
    },
  },
  plugins: [],
};
