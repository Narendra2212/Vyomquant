# Aerora Dynamics — Windows Desktop App + Cloud Backend

This package converts the Aerora Dynamics platform into a **native Windows desktop application** (Electron) backed by a **cloud-hosted FastAPI server**. Every team member runs the same lightweight Windows app; all data lives centrally in the cloud — no more "which laptop has the database" problems.

```
┌─────────────────────┐         ┌──────────────────────────┐
│  Windows Desktop App │  HTTPS  │   Cloud API (FastAPI)    │
│  (Electron + React)  │ ──────► │   + FundOS + Sales DB    │
│  Installed on every  │         │   Hosted on your VPS/    │
│  team member's PC    │         │   Railway/Render/AWS     │
└─────────────────────┘         └──────────────────────────┘
```

---

## What's in this package

```
aerora_windows/
├── electron/              ← The Windows desktop app source
│   ├── src/main/           Electron main process (window, tray, IPC)
│   ├── src/renderer/       React UI (all 12 platform pages)
│   ├── assets/             App icon (aerora.ico)
│   ├── package.json        Build config (electron-builder → .exe)
│   ├── tailwind.config.js
│   └── postcss.config.js
│
├── cloud/                  ← The cloud-hosted backend
│   ├── api/main.py         Unified FastAPI app — mounts 13 routers
│   ├── api/routers/        auth, metrics, leads, email, social, ai,
│   │                       build, hr, finance, compliance,
│   │                       investors (FundOS proxy), users, bridge
│   ├── docker/              Dockerfile + docker-compose.prod.yml
│   ├── nginx/                Production reverse-proxy + SSL config
│   ├── scripts/deploy.sh     One-command cloud deployment
│   └── .env.production.example
│
└── installer/
    └── installer.nsh        NSIS customisation (protocol handler, firewall rule)
```

---

## Part 1 — Deploy the Cloud Backend

The desktop app needs a live API to talk to. Deploy this **once**, on any cloud provider.

### Option A: Docker on a VPS (recommended, ~£10/month)

```bash
# On your VPS (Ubuntu 22.04+, DigitalOcean/Hetzner/Linode)
git clone <your-repo> /opt/aerora
cd /opt/aerora

cp cloud/.env.production.example .env.production
nano .env.production    # fill in JWT_SECRET, ADMIN_PASSWORD, API keys

chmod +x cloud/scripts/deploy.sh
./cloud/scripts/deploy.sh
```

This builds and starts:
- **aerora-api** — the FastAPI backend (port 8080)
- **aerora-bridge-scheduler** — syncs FundOS ↔ Sales every 15 min
- **nginx** — SSL termination and reverse proxy (ports 80/443)
- **redis** — for FundOS Celery workers (if used)

### Option B: Railway / Render (zero-server, easiest)

1. Push this repo to GitHub
2. Connect the repo in Railway/Render
3. Set the build context to `cloud/docker/Dockerfile`
4. Add all variables from `.env.production.example` in their dashboard
5. Deploy — you'll get a URL like `https://aerora-api.up.railway.app`

### Verify it's running

```bash
curl https://your-api-url.com/api/health
# {"status":"healthy","version":"2.0.0","db_leads":0}
```

Visit `https://your-api-url.com/docs` for the full interactive API reference (all 60+ endpoints).

---

## Part 2 — Build the Windows Desktop App

### Prerequisites (on a Windows or cross-compile-capable machine)
- Node.js 18+ — https://nodejs.org
- Python 3.11+ (for `electron-builder` native deps)

### Build steps

```bash
cd electron
npm install

# Point the app at your deployed cloud API
echo "AERORA_API_URL=https://your-api-url.com" > .env

# Development mode (hot reload)
npm run dev

# Production build → produces a Windows installer
npm run build
```

The output lands in `electron/dist/`:
```
AeroraDynamics-Setup-2.0.0.exe     ← Installer (NSIS)
AeroraDynamics-2.0.0-portable.exe  ← No-install portable version
```

### What the installer does
- Installs to `Program Files\Aerora Dynamics`
- Creates Desktop + Start Menu shortcuts
- Registers the `aerora://` deep-link protocol
- Adds an outbound firewall rule for the app
- Sets up auto-update checking (every 2 hours, via GitHub Releases)

### Distributing to your team

Send each team member `AeroraDynamics-Setup-2.0.0.exe`. They run it, it installs in under a minute, and they log in with the credentials you create in Platform Admin — exactly like before, just in a native window instead of a browser tab.

---

## How It All Connects

1. **User double-clicks the desktop icon** → Electron window opens, custom title bar, system tray icon appears
2. **Login screen** checks cloud API health every 15 seconds — shows "Connected to cloud" or "Cloud offline"
3. **User signs in** → JWT token stored encrypted via `electron-store`, never touches disk in plaintext
4. **Sidebar renders** based on role — same RBAC logic as before, now enforced server-side via the `auth_router.py` dependency on every endpoint
5. **Every page** (Dashboard, Sales, Fundraising, Build & Ops, Finance, HR, Compliance, Bridge, Admin) calls the cloud API via React Query — same data, same permissions, now from anywhere with internet
6. **Closing the window** minimizes to system tray — the app keeps running so notifications still arrive
7. **Auto-updater** checks GitHub Releases every 2 hours and silently downloads updates, prompting to restart when ready

---

## Updating the App Later

When you ship a new version:

```bash
cd electron
npm version patch          # bumps version in package.json
npm run build              # rebuilds installer
```

Upload the new installer to your GitHub Releases page (matching the `publish.owner`/`repo` in `package.json`). Every installed copy will auto-detect and download it within 2 hours.

---

## Security Notes

- JWT tokens expire after 8 hours (`JWT_EXPIRES_HOURS` in cloud `.env`)
- All API calls require `Authorization: Bearer <token>` — enforced by `auth_router.get_current_user` dependency on every route
- The Electron renderer process has **zero direct Node.js access** — `contextIsolation: true`, `nodeIntegration: false`. All privileged operations go through the `preload.js` bridge
- CORS is locked to `app://.` (Electron production) and your specific domains — not wildcard
- Content-Security-Policy header blocks any script/resource loading outside the cloud API domain

---

## Troubleshooting

**"Cloud offline" on login screen**
Check `AERORA_API_URL` is reachable: `curl https://your-api-url.com/api/health`

**Build fails with native module errors**
Run `npm run postinstall` to rebuild native deps for Electron's Node version.

**App won't start after install**
Check `%APPDATA%\aerora-dynamics\logs` for crash logs (if you add electron-log) or run from a terminal: `"C:\Program Files\Aerora Dynamics\AeroraDynamics.exe"` to see console output.

**Bridge sync not running on the cloud**
Check the scheduler container: `docker-compose -f cloud/docker/docker-compose.prod.yml logs aerora-bridge-scheduler`
