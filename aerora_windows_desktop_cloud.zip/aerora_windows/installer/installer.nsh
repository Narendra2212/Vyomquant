; ============================================================
; Aerora Dynamics — Windows Installer
; installer/installer.nsh — NSIS Customization Script
;
; Referenced by electron-builder's "nsis.include" config option.
; Adds custom branding, registry entries, and a deep-link
; protocol handler (aerora://) registration.
; ============================================================

!macro customHeader
  !system "echo Building Aerora Dynamics installer..."
!macroend

!macro preInit
  ; Set default install directory under Program Files
  SetRegView 64
  WriteRegExpandStr HKLM "SOFTWARE\AeroraDynamics" "InstallPath" "$PROGRAMFILES64\Aerora Dynamics"
!macroend

!macro customInstall
  ; ── Register aerora:// deep-link protocol ──────────────────
  DetailPrint "Registering aerora:// protocol handler..."
  WriteRegStr HKCU "Software\Classes\aerora" "" "URL:Aerora Dynamics Protocol"
  WriteRegStr HKCU "Software\Classes\aerora" "URL Protocol" ""
  WriteRegStr HKCU "Software\Classes\aerora\DefaultIcon" "" "$INSTDIR\AeroraDynamics.exe,0"
  WriteRegStr HKCU "Software\Classes\aerora\shell\open\command" "" '"$INSTDIR\AeroraDynamics.exe" "%1"'

  ; ── Firewall rule (allow outbound HTTPS to cloud API) ──────
  DetailPrint "Configuring firewall rule..."
  nsExec::Exec 'netsh advfirewall firewall add rule name="Aerora Dynamics" dir=out action=allow program="$INSTDIR\AeroraDynamics.exe" enable=yes'

  ; ── Write version info to registry ─────────────────────────
  WriteRegStr HKLM "SOFTWARE\AeroraDynamics" "Version" "${VERSION}"
  WriteRegStr HKLM "SOFTWARE\AeroraDynamics" "InstallDate" "$%DATE%"
!macroend

!macro customUnInstall
  DetailPrint "Removing Aerora Dynamics protocol handler..."
  DeleteRegKey HKCU "Software\Classes\aerora"
  DeleteRegKey HKLM "SOFTWARE\AeroraDynamics"
  nsExec::Exec 'netsh advfirewall firewall delete rule name="Aerora Dynamics"'
!macroend
